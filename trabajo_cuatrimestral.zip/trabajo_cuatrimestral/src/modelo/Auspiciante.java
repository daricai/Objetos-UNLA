package modelo;


public class Auspiciante extends PersonaJuridica {
	private double aporteConferencia;
	//constructor
	public Auspiciante(int idPersona, Contacto contacto, String razonSocial, String cuit, double aporteConferencia) {
		super(idPersona, contacto, razonSocial, cuit);
		this.aporteConferencia = aporteConferencia;
	}
	//Getter y setter
	public double getAporteConferencia() {
		return aporteConferencia;
	}
	public void setAporteConferencia(double aporteConferencia) {
		this.aporteConferencia = aporteConferencia;
	}
	//toString
	@Override
	public String toString() {
		return "Auspiciante [idPersona=" + idPersona +", "+ contacto.toString() + ", razonSocial=" + razonSocial + ", cuit=" + cuit +", aporteConferencia=" + aporteConferencia + "]";
	}
	
}
