package modelo;

public class Espectador extends PersonaFisica  {
	private String nivelEstudio;
	//constructor
	public Espectador(int idPersona, Contacto contacto, String nombre, String apellido, String tipoDocumento, long dni,
			String nivelEstudio) {
		super(idPersona, contacto, nombre, apellido, tipoDocumento, dni);
		this.nivelEstudio = nivelEstudio;
	}
	//getter y setter
	public String getNivelEstudio() {
		return nivelEstudio;
	}

	public void setNivelEstudio(String nivelEstudio) {
		this.nivelEstudio = nivelEstudio;
	}
	//toString
	@Override
	public String toString() {
		return "Espectador [idPersona=" + idPersona +", "+ contacto.toString() + ", nombre=" + nombre + ", apellido=" + apellido
			+ ", tipoDocumento=" + tipoDocumento + ", nroDocumento=" + nroDocumento + ", nivelEstudio=" + nivelEstudio + "]";
	}
}
