package modelo;
import modelo.Contacto;

public abstract class Persona {
	protected int idPersona;
	protected Contacto contacto;
	//constructor
	public Persona(int idPersona, Contacto contacto) {
		super();
		this.idPersona = idPersona;
		this.contacto = contacto;
	}
	//getter y setter
	public int getIdPersona() {
		return idPersona;
	}
	public void setIdPersona(int idPersona) {
		this.idPersona = idPersona;
	}
	public Contacto getContacto() {
		return contacto;
	}
	public void setContacto(Contacto contacto) {
		this.contacto = contacto;
	}
	//toString
	@Override
	public String toString() {
		return "Persona [idPersona=" + idPersona + ", contacto=" + contacto + "]";
	}
}