package modelo;

import java.time.LocalTime;

public class Virtual extends Exposicion {
	private String medioDifusion;
	private String url;
	//constructor
	public Virtual(int idExposicion, String conferencia, Orador orador, double costoRealizacion, LocalTime horaInicio, LocalTime horaFin,
			String medioDifusion, String url) {
		super(idExposicion, conferencia, orador, costoRealizacion, horaInicio, horaFin);
		this.medioDifusion = medioDifusion;
		this.url = url;
	}
	//getter y setter
	public String getMedioDifusion() {
		return medioDifusion;
	}
	public void setMedioDifusion(String medioDifusion) {
		this.medioDifusion = medioDifusion;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	//toString
	@Override
	public String toString() {
		return "Virtual [idExposicion=" + idExposicion + " conferencia=" + conferencia
				+ ", orador=" + orador + ", costoRealizacion=" + costoRealizacion + ", horaInicio=" + horaInicio
				+ ", horaFin=" + horaFin + "medioDifusion=" + medioDifusion + ", url=" + url + " ]";
	}
	
}
