package modelo;

import java.time.LocalDate;

public class Virtual extends Exposicion {
	private String medioDifusion;
	private String url;
	//constructor
	public Virtual(int idExposicion, Orador orador, float costoRealizacion, LocalDate horaInicio, LocalDate horaFin,
			String medioDifusion, String url) {
		super(idExposicion, orador, costoRealizacion, horaInicio, horaFin);
		this.medioDifusion = medioDifusion;
		this.url = url;
	}
	//getter y setter
	public String getMedioDifusion() {
		return medioDifusion;
	}
	public void setMedioDifusion(String medioDifusion) {
		this.medioDifusion = medioDifusion;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	//toString
	@Override
	public String toString() {
		return "Virtual [medioDifusion=" + medioDifusion + ", url=" + url + "]";
	}
}
