package modelo;

public abstract class PersonaJuridica extends Persona {
	protected String razonSocial;
	protected String cuit;
	//CONSTRUCTOR
	public PersonaJuridica(int idPersona, Contacto contacto, String razonSocial, String cuit) {
		super(idPersona, contacto);
		this.razonSocial = razonSocial;
		this.cuit = cuit;
	}
	//getter y setter
	public String getRazonSocial() {
		return razonSocial;
	}
	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}
	public String getCuit() {
		return cuit;
	}
	public void setCuit(String cuit) {
		this.cuit = cuit;
	}
	//toString
	@Override
	public String toString() {
		return "PersonaJuridica [razonSocial=" + razonSocial + ", cuit=" + cuit + "]";
	}
}
