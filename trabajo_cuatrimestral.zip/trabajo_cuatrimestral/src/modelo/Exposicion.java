package modelo;

import java.time.LocalTime;

public abstract class Exposicion {
	protected int idExposicion;
	protected String conferencia;
	protected Orador orador;
	protected double costoRealizacion;
	protected LocalTime horaInicio;
	protected LocalTime horaFin;

	// constructor
	public Exposicion(int idExposicion, String conferencia, Orador orador, double costoRealizacion,
			LocalTime horaInicio, LocalTime horaFin) {
		super();
		this.idExposicion = idExposicion;
		this.conferencia = conferencia;
		this.orador = orador;
		this.costoRealizacion = costoRealizacion;
		this.horaInicio = horaInicio;
		this.horaFin = horaFin;
	}

	// getter y setter
	public int getIdExposicion() {
		return idExposicion;
	}
	public void setIdExposicion(int idExposicion) {
		this.idExposicion = idExposicion;
	}
	public String getConferencia() {
		return conferencia;
	}
	public void setConferencia(String conferencia) {
		this.conferencia = conferencia;
	}
	public Orador getOrador() {
		return orador;
	}
	public void setOrador(Orador orador) {
		this.orador = orador;
	}
	public double getCostoRealizacion() {
		return costoRealizacion;
	}
	public void setCostoRealizacion(double costoRealizacion) {
		this.costoRealizacion = costoRealizacion;
	}
	public LocalTime getHoraInicio() {
		return horaInicio;
	}
	public void setHoraInicio(LocalTime horaInicio) {
		this.horaInicio = horaInicio;
	}
	public LocalTime getHoraFin() {
		return horaFin;
	}
	public void setHoraFin(LocalTime horaFin) {
		this.horaFin = horaFin;
	}
	// toString
	@Override
	public String toString() {
		return "Exposicion [idExposicion=" + idExposicion + ", conferencia=" + conferencia + ", orador=" + orador
				+ ", costoRealizacion=" + costoRealizacion + ", horaInicio=" + horaInicio + ", horaFin=" + horaFin
				+ "]";
	}

}
