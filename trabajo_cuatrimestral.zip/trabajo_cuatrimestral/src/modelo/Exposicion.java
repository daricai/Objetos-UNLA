package modelo;

import java.time.LocalDate;

public abstract class Exposicion {
	protected int idExposicion;
	protected Orador orador;
	protected double costoRealizacion;
	protected LocalDate horaInicio;
	protected LocalDate horaFin;
	//constructor
	public Exposicion(int idExposicion, Orador orador, double costoRealizacion, LocalDate horaInicio,
			LocalDate horaFin) {
		super();
		this.idExposicion = idExposicion;
		this.orador = orador;
		this.costoRealizacion = costoRealizacion;
		this.horaInicio = horaInicio;
		this.horaFin = horaFin;
	}
	//getter y setter
	public int getIdExposicion() {
		return idExposicion;
	}
	public void setIdExposicion(int idExposicion) {
		this.idExposicion = idExposicion;
	}
	public Orador getOrador() {
		return orador;
	}
	public void setOrador(Orador orador) {
		this.orador = orador;
	}
	public double getCostoRealizacion() {
		return costoRealizacion;
	}
	public void setCostoRealizacion(double costoRealizacion) {
		this.costoRealizacion = costoRealizacion;
	}
	public LocalDate getHoraInicio() {
		return horaInicio;
	}
	public void setHoraInicio(LocalDate horaInicio) {
		this.horaInicio = horaInicio;
	}
	public LocalDate getHoraFin() {
		return horaFin;
	}
	public void setHoraFin(LocalDate horaFin) {
		this.horaFin = horaFin;
	}
	//toString
	@Override
	public String toString() {
		return "Exposicion [idExposicion=" + idExposicion + ", orador=" + orador + ", costoRealizacion="
				+ costoRealizacion + ", horaInicio=" + horaInicio + ", horaFin=" + horaFin + "]";
	}
}
