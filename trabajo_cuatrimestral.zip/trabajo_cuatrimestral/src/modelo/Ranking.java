package modelo;

public class Ranking implements Comparable <Ranking>{
	String texto;
	int numero;
	//constructor
	public Ranking(String texto, int numero) {
		super();
		this.texto = texto;
		this.numero = numero;
	}
	//getter y setter
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto = texto;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	//toString
	@Override
	public String toString() {
		return texto + ": " + numero;
	}
	@Override
	public int compareTo(Ranking o) {
		int devolver=0;
		if(numero < o.getNumero()) {
			devolver = 1;
		}
		else {
			if(numero > o.getNumero()) {
				devolver = -1;
			}
		}
		return devolver;
	}
	
}
