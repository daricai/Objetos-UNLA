package modelo;
import modelo.Espectador;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Presencial extends Exposicion {
	private List<Espectador> lstEspectadores;
	//constructor
	public Presencial(int idExposicion, String conferencia, Orador orador, double costoRealizacion, LocalTime horaInicio,
			LocalTime horaFin) {
		super(idExposicion, conferencia, orador, costoRealizacion, horaInicio, horaFin);
		this.lstEspectadores = new ArrayList<Espectador>();
	}
	//getter y setter
	public List<Espectador> getLstEspectador() {
		return lstEspectadores;
	}
	public void setLstEspectador(List<Espectador> lstEspectadores) {
		this.lstEspectadores = lstEspectadores;
	}
	//toString
	@Override
	public String toString() {
		return "Presencial [idExposicion=" + idExposicion + " conferencia=" + conferencia + ", orador="
				+ orador + ", costoRealizacion=" + costoRealizacion + ", horaInicio=" + horaInicio + ", horaFin="
				+ horaFin + "lstEspectadores=" + lstEspectadores + "]";
	}
	
	public boolean agregarEspectador (Espectador espectador) {
		return(lstEspectadores.add(espectador));
	}
	
}
