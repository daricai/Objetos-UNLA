package modelo;
import modelo.Espectador;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Presencial extends Exposicion {
	private List<Espectador> lstEspectadores;
	//constructor
	public Presencial(int idExposicion, Orador orador, float costoRealizacion, LocalDate horaInicio,
			LocalDate horaFin) {
		super(idExposicion, orador, costoRealizacion, horaInicio, horaFin);
		this.lstEspectadores = new ArrayList<Espectador>();
	}
	//getter y setter
	public List<Espectador> getLstEspectador() {
		return lstEspectadores;
	}
	public void setLstEspectador(List<Espectador> lstEspectadores) {
		this.lstEspectadores = lstEspectadores;
	}
	//toString
	@Override
	public String toString() {
		return "Presencial [lstEspectador=" + lstEspectadores + "]";
	}
}
