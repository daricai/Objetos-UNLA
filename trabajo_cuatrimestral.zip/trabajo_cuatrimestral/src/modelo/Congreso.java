package modelo;
import modelo.Persona;
import modelo.Conferencia;
import modelo.Entrada;
import modelo.Funciones;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Congreso {
	private String nombre;
	private LocalDate fechaInicio;
	private LocalDate fechaFin;
	private double ingreso;
	private List<Persona> lstPersonas;
	private List<Conferencia> lstConferencias;
	private List<Entrada> lstEntradas;
	//constructor
	public Congreso(String nombre, LocalDate fechaInicio, LocalDate fechaFin, double ingreso) {
		super();
		this.nombre = nombre;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
		this.ingreso = ingreso;
		this.lstPersonas = new ArrayList<Persona>();
		this.lstConferencias = new ArrayList<Conferencia>();
		this.lstEntradas = new ArrayList<Entrada>();
	}
	//getter y setter
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public LocalDate getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(LocalDate fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public LocalDate getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(LocalDate fechaFin) {
		this.fechaFin = fechaFin;
	}
	public double getIngreso() {
		return ingreso;
	}
	public void setIngreso(double ingreso) {
		this.ingreso = ingreso;
	}
	public List<Persona> getLstPersonas() {
		return lstPersonas;
	}
	public void setLstPersonas(List<Persona> lstPersonas) {
		this.lstPersonas = lstPersonas;
	}
	public List<Conferencia> getLstConferencias() {
		return lstConferencias;
	}
	public void setLstConferencias(List<Conferencia> lstConferencias) {
		this.lstConferencias = lstConferencias;
	}
	public List<Entrada> getLstEntradas() {
		return lstEntradas;
	}
	public void setLstEntradas(List<Entrada> lstEntradas) {
		this.lstEntradas = lstEntradas;
	}
	//toString
	@Override
	public String toString() {
		return "Congreso [nombre=" + nombre + ", fechaInicio=" + fechaInicio + ", fechaFin=" + fechaFin + ", ingreso="
				+ ingreso + ", lstPersonas=" + lstPersonas + ", lstConferencias=" + lstConferencias + ", lstEntradas="
				+ lstEntradas + "]";
	}
	//AUSPICIANTES
	//AUSPICIANTES
	//AUSPICIANTES
	//AUSPICIANTES
	public List<Auspiciante> traerAuspiciante (){
		List <Auspiciante> lstAuspiciantes= new ArrayList<Auspiciante>();
		int i;
		for (i=0; i<lstPersonas.size();i++) {
			if(lstPersonas.get(i) instanceof Auspiciante) {
				lstAuspiciantes.add((Auspiciante)lstPersonas.get(i));
			}
		}
		return (lstAuspiciantes);
	}
	public Auspiciante traerAuspiciante (String cuit) {
		List <Auspiciante> lstAuspiciantes = traerAuspiciante();
		int flag =0;
		Auspiciante auspi = null;
		int i=0;
		while (i<lstAuspiciantes.size() && flag ==0) {
			if(lstAuspiciantes.get(i).getCuit()==cuit) {
				flag=1;
				auspi = lstAuspiciantes.get(i);
			}
			i++;
		}
		return auspi;
	}
	
	public boolean agregarAuspiciante (Contacto contacto, String razonSocial, String cuit, double aporteConferencia) throws Exception {
		if(this.traerAuspiciante(cuit)!=null) throw new Exception ("Error: El cuit "+ cuit+ " del auspiciante ya esta registrado");
		int idAuspiciante =1;
		if(lstPersonas.size()!=0) {
			idAuspiciante = lstPersonas.get(lstPersonas.size()-1).getIdPersona() +1;
		}
		return(lstPersonas.add(new Auspiciante (idAuspiciante, contacto, razonSocial,cuit, aporteConferencia)));		
	}
	
	public boolean EliminarAuspiciante (String cuit) throws Exception {
		if(this.traerAuspiciante(cuit)==null) throw new Exception ("Error: El cuit " + cuit + " del auspiciante no se encuentra registrado para eliminar");
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != traerAuspiciante(cuit).getIdPersona()) {
			i++;
		}
		lstPersonas.remove(i);
		return true;		
	}
	
	public boolean modificarAuspiciante (String cuit, double aporteConferenciaModificado) throws Exception {
		if(this.traerAuspiciante(cuit)==null) throw new Exception ("Error: El cuit " + cuit + " del auspiciante no se encuentra registrado para modificar");
		Auspiciante auspi = traerAuspiciante(cuit);
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != auspi.getIdPersona()) {
			i++;
		}
		auspi.setAporteConferencia(aporteConferenciaModificado);
		lstPersonas.add(i, auspi);
		lstPersonas.remove(i+1);
		return true;		
	}
	//PERSONA FISICA
	//PERSONA FISICA
	//PERSONA FISICA
	//PERSONA FISICA
	public List<PersonaFisica> traerPersonaFisica (){
		List <PersonaFisica> lstPersonasFisicas= new ArrayList<PersonaFisica>();
		int i;
		for (i=0; i<lstPersonas.size();i++) {
			if(lstPersonas.get(i) instanceof PersonaFisica) {
				lstPersonasFisicas.add((PersonaFisica)lstPersonas.get(i));
			}
		}
		return (lstPersonasFisicas);
	}
	
	public PersonaFisica traerPersonaFisica (long nroDocumento) {
		List <PersonaFisica> lstPersonasFisicas= traerPersonaFisica();
		int flag =0;
		PersonaFisica personaFisica = null;
		int i=0;
		while (i<lstPersonasFisicas.size() && flag ==0) {
			if(lstPersonasFisicas.get(i).getNroDocumento()==nroDocumento) {
				flag=1;
				personaFisica = lstPersonasFisicas.get(i);
			}
			i++;
		}
		return personaFisica;
	}
	//ORADORES
	//ORADORES
	//ORADORES
	//ORADORES
	public boolean agregarOrador (Contacto contacto, String nombre, String apellido, String tipoDocumento, long nroDocumento, String areaInvestigacion) throws Exception {
		if(this.traerPersonaFisica(nroDocumento)!=null) throw new Exception ("Error: El numero de documento " +nroDocumento+ " ya esta registrado");
		int idOrador =1;
		if(lstPersonas.size()!=0) {
			idOrador = lstPersonas.get(lstPersonas.size()-1).getIdPersona() +1;
		}
		return(lstPersonas.add(new Orador (idOrador, contacto, nombre, apellido, tipoDocumento, nroDocumento, areaInvestigacion)));
	}
	
	
	public boolean EliminarOrador (long nroDocumento) throws Exception {
		if(this.traerPersonaFisica(nroDocumento)==null) throw new Exception ("Error: El numero de documento " + nroDocumento + " del orador no se encuentra registrado para eliminar");
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != traerPersonaFisica(nroDocumento).getIdPersona()) {
			i++;
		}
		if(!(lstPersonas.get(i) instanceof Orador)) throw new Exception ("Error: El numero de documento " + nroDocumento + " del orador no se encuentra registrado para eliminar");
		lstPersonas.remove(i);
		return true;		
	}
	
	public boolean modificarOrador (long nroDocumento, String areaInvestigacion) throws Exception {
		if(this.traerPersonaFisica(nroDocumento)==null) throw new Exception ("Error: El numero de documento " + nroDocumento + " del orador no se encuentra registrado para modificar");
		PersonaFisica personaFisica= traerPersonaFisica(nroDocumento);
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != personaFisica.getIdPersona()) {
			i++;
		}
		if(!(lstPersonas.get(i) instanceof Orador)) throw new Exception ("Error: El numero de documento " + nroDocumento + " del orador no se encuentra registrado para modificar");
		Orador ora= (Orador) personaFisica;
		ora.setAreaInvestigacion(areaInvestigacion);
		lstPersonas.add(i, ora);
		lstPersonas.remove(i+1);
		return true;	
	}
	//ORGANIZADORES
	//ORGANIZADORES
	//ORGANIZADORES
	//ORGANIZADORES	
	public boolean agregarOrganizador (Contacto contacto, String nombre, String apellido, String tipoDocumento, long nroDocumento) throws Exception {
		if(this.traerPersonaFisica(nroDocumento)!=null) throw new Exception ("Error: El numero de documento " +nroDocumento+ " ya esta registrado");
		int idOrganizador =1;
		if(lstPersonas.size()!=0) {
			idOrganizador = lstPersonas.get(lstPersonas.size()-1).getIdPersona() +1;
		}
		return(lstPersonas.add(new Organizador (idOrganizador, contacto, nombre, apellido, tipoDocumento, nroDocumento)));
	}
	
	
	public boolean EliminarOrganizador (long nroDocumento) throws Exception {
		if(this.traerPersonaFisica(nroDocumento)==null) throw new Exception ("Error: El numero de documento " + nroDocumento + " del organizador no se encuentra registrado para eliminar");
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != traerPersonaFisica(nroDocumento).getIdPersona()) {
			i++;
		}
		if(!(lstPersonas.get(i) instanceof Organizador)) throw new Exception ("Error: El numero de documento " + nroDocumento + " del organizador no se encuentra registrado para eliminar");
		lstPersonas.remove(i);
		return true;
	}
	
	//public boolean modificarOrador (long nroDocumento, String areaInvestigacion) throws Exception {
	
	//ESPECTADOR
	//ESPECTADOR
	//ESPECTADOR
	//ESPECTADOR
	public boolean agregarEspectador (Contacto contacto, String nombre, String apellido, String tipoDocumento, long nroDocumento, String nivelEstudio) throws Exception {
		if(this.traerPersonaFisica(nroDocumento)!=null) throw new Exception ("Error: El numero de documento " +nroDocumento+ " ya esta registrado");
		int idEspectador =1;
		if(lstPersonas.size()!=0) {
			idEspectador = lstPersonas.get(lstPersonas.size()-1).getIdPersona() +1;
		}
		return(lstPersonas.add(new Espectador (idEspectador, contacto, nombre, apellido, tipoDocumento, nroDocumento, nivelEstudio)));
	}
	
	
	public boolean EliminarEspectador (long nroDocumento) throws Exception {
		if(this.traerPersonaFisica(nroDocumento)==null) throw new Exception ("Error: El numero de documento " + nroDocumento + " del espectador no se encuentra registrado para eliminar");
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != traerPersonaFisica(nroDocumento).getIdPersona()) {
			i++;
		}
		if(!(lstPersonas.get(i) instanceof Espectador)) throw new Exception ("Error: El numero de documento " + nroDocumento + " del espectador no se encuentra registrado para eliminar");
		lstPersonas.remove(i);
		return true;
	}
	
	public boolean modificarEspectador (long nroDocumento, String nivelEstudio) throws Exception {
		if(this.traerPersonaFisica(nroDocumento)==null) throw new Exception ("Error: El numero de documento " + nroDocumento + " del espectador no se encuentra registrado para modificar");
		PersonaFisica personaFisica= traerPersonaFisica(nroDocumento);
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != personaFisica.getIdPersona()) {
			i++;
		}
		if(!(lstPersonas.get(i) instanceof Espectador)) throw new Exception ("Error: El numero de documento " + nroDocumento + " del espectador no se encuentra registrado para modificar");
		Espectador espec= (Espectador) personaFisica;
		espec.setNivelEstudio(nivelEstudio);
		lstPersonas.add(i, espec);
		lstPersonas.remove(i+1);
		return true;		
	}
	
	//CONFERENCIAS
	//CONFERENCIAS
	//CONFERENCIAS
	//CONFERENCIAS
	public Conferencia traerConferencia (String titulo) {
		int flag =0;
		Conferencia confe = null;
		int i=0;
		while (i<lstConferencias.size() && flag ==0) {
			if(lstConferencias.get(i).getTitulo()==titulo) {
				flag=1;
				confe = lstConferencias.get(i);
			}
			i++;
		}
		return confe;
	}
	
	public boolean agregarConferencia (String titulo, LocalDate diaConferencia, Sala sala) throws Exception {
		if(this.traerConferencia(titulo)!=null) throw new Exception ("Error: El titulo " + titulo + " ya esta registrado");
		if(diaConferencia.isAfter(fechaFin)) throw new Exception ("Error: la fecha ingresada no es correcta");
		if(diaConferencia.isBefore(fechaInicio)) throw new Exception ("Error: la fecha ingresada no es correcta");
		int idConferencia =1;
		if(lstConferencias.size()!=0) {
			idConferencia = lstConferencias.get(lstConferencias.size()-1).getIdConferencia() +1;
		}
		return(lstConferencias.add(new Conferencia (idConferencia, titulo, diaConferencia,sala)));		
	}
	
	public boolean EliminarConferencia (String titulo) throws Exception {
		if(this.traerConferencia(titulo)==null) throw new Exception ("Error: El titulo " + titulo + " de la conferencia no se encuentra registrado para eliminar");
		int i=0;
		while (lstConferencias.get(i).getTitulo() != titulo) {
			i++;
		}
		lstConferencias.remove(i);
		return true;		
	}
	
	public boolean modificarConferencia (String titulo, String tituloNuevo, LocalDate diaConferencia, Sala sala) throws Exception {
		if(this.traerConferencia(titulo)==null) throw new Exception ("Error: El titulo " + titulo + " de la conferencia no se encuentra registrado para modificar");
		if(diaConferencia.isAfter(fechaFin)) throw new Exception ("Error: la fecha ingresada no es correcta");
		if(diaConferencia.isBefore(fechaInicio)) throw new Exception ("Error: la fecha ingresada no es correcta");
		int i=0;
		while (lstConferencias.get(i).getTitulo() != titulo) {
			i++;
		}
		lstConferencias.get(i).setTitulo(tituloNuevo);
		lstConferencias.get(i).setDiaConferencia(diaConferencia);
		lstConferencias.get(i).setSala(sala);
		return true;		
	}
	//ENTRADAS
	//ENTRADAS
	//ENTRADAS
	//ENTRADAS
	public int calcularDigitoVerificador (String codIngreso) {
		int suma=0;
		for (int i=0; i<3; i++) {
			suma = suma + (Character.getNumericValue(codIngreso.charAt(i)));
		}
		for (int i=3; i<6; i++) {
			suma = suma + ((Character.getNumericValue(codIngreso.charAt(i)) * 4));
		}
		suma = suma + (Character.getNumericValue(codIngreso.charAt(6)));
		return (suma % 10);
	}

	public boolean esCodIngresoValido (String codIngreso) {
		boolean retorno = false;
		if (Funciones.esCadenaNros(codIngreso)) {
			if(codIngreso.length() == 7) {
				if(calcularDigitoVerificador(codIngreso) == 0) {
					retorno = true;
				}
			}
		}
		return retorno;
	}
	
	public Entrada traerEntrada (String codigo) {
		int flag =0;
		Entrada entrada = null;
		int i=0;
		while (i<lstEntradas.size() && flag ==0) {
			if(lstEntradas.get(i).getCodigo()==codigo) {
				flag=1;
				entrada = lstEntradas.get(i);
			}
			i++;
		}
		return entrada;
	}
	
	public boolean agregarEntrada (String codigo, LocalDate fechaCompra, LocalTime horaCompra, float precioEntrada, Espectador espectador, Conferencia conferencia) throws Exception {
		if(this.traerEntrada(codigo)!=null) throw new Exception ("Error: El codigo " + codigo + " ya esta registrado");
		if(!esCodIngresoValido(codigo)) throw new Exception ("Error: El codigo " + codigo + " es incorrecto");
		int idEntrada =1;
		if(lstEntradas.size()!=0) {
			idEntrada = lstEntradas.get(lstEntradas.size()-1).getIdEntrada() +1;
		}
		return(lstEntradas.add(new Entrada (idEntrada, codigo, LocalDate.now(), LocalTime.now(), precioEntrada, espectador, conferencia)));		
	}
	
	public boolean EliminarEntrada (String codigo) throws Exception {
		if(this.traerEntrada(codigo)==null) throw new Exception ("Error: El codigo " + codigo + " de la entrada no se encuentra registrado para eliminar");
		int i=0;
		while (lstEntradas.get(i).getCodigo() != codigo) {
			i++;
		}
		lstEntradas.remove(i);
		return true;		
	}
	
	public boolean modificarEntrada (String codigo, float precioEntrada, Espectador espectador, Conferencia conferencia) throws Exception {
		if(this.traerEntrada(codigo)==null) throw new Exception ("Error: El codigo " + codigo + " de la entrada no se encuentra registrado para modificar");
		int i=0;
		while (lstEntradas.get(i).getCodigo() != codigo) {
			i++;
		}
		lstEntradas.get(i).setPrecioEntrada(precioEntrada);
		lstEntradas.get(i).setEspectador(espectador);
		lstEntradas.get(i).setConferencia(conferencia);
		return true;		
	}
}
