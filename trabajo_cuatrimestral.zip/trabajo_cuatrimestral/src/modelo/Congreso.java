package modelo;
import modelo.Persona;
import modelo.Conferencia;
import modelo.Entrada;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Congreso {
	private String nombre;
	private LocalDate fechaInicio;
	private LocalDate fechaFin;
	private double ingreso;
	private List<Persona> lstPersonas;
	private List<Conferencia> lstConferencias;
	private List<Entrada> lstEntradas;
	private List<Sala> lstSalas;
	//constructor
	public Congreso(String nombre, LocalDate fechaInicio, LocalDate fechaFin, double ingreso) {
		super();
		this.nombre = nombre;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
		this.ingreso = ingreso;
		this.lstPersonas = new ArrayList<Persona>();
		this.lstConferencias = new ArrayList<Conferencia>();
		this.lstEntradas = new ArrayList<Entrada>();
		this.lstSalas = new ArrayList<Sala>();
	}
	//getter y setter
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public LocalDate getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(LocalDate fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public LocalDate getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(LocalDate fechaFin) {
		this.fechaFin = fechaFin;
	}
	public double getIngreso() {
		return ingreso;
	}
	public void setIngreso(double ingreso) {
		this.ingreso = ingreso;
	}
	public List<Persona> getLstPersonas() {
		return lstPersonas;
	}
	public void setLstPersonas(List<Persona> lstPersonas) {
		this.lstPersonas = lstPersonas;
	}
	public List<Conferencia> getLstConferencias() {
		return lstConferencias;
	}
	public void setLstConferencias(List<Conferencia> lstConferencias) {
		this.lstConferencias = lstConferencias;
	}
	public List<Entrada> getLstEntradas() {
		return lstEntradas;
	}
	public void setLstEntradas(List<Entrada> lstEntradas) {
		this.lstEntradas = lstEntradas;
	}
	public List<Sala> getLstSalas() {
		return lstSalas;
	}
	public void setLstSalas(List<Sala> lstSalas) {
		this.lstSalas = lstSalas;
	}
	//toString
	@Override
	public String toString() {
		return "Congreso [nombre=" + nombre + ", fechaInicio=" + fechaInicio + ", fechaFin=" + fechaFin + ", ingreso="
				+ ingreso + ", lstPersonas=" + lstPersonas + ", lstConferencias=" + lstConferencias + ", lstEntradas="
				+ lstEntradas + ", lstSalas=" + lstSalas + "]";
	}
	
	//AUSPICIANTES
	//AUSPICIANTES
	//AUSPICIANTES
	//AUSPICIANTES
	
	// CU 1 - List<Auspiciante> traerAuspiciante ()
	public List<Auspiciante> traerAuspiciante (){
		List <Auspiciante> lstAuspiciantes= new ArrayList<Auspiciante>();
		int i;
		for (i=0; i<lstPersonas.size();i++) {
			if(lstPersonas.get(i) instanceof Auspiciante) {
				lstAuspiciantes.add((Auspiciante)lstPersonas.get(i));
			}
		}
		return (lstAuspiciantes);
	}
	// CU 2 - Auspiciante traerAuspiciante (String cuit)
	public Auspiciante traerAuspiciante (String cuit) {
		Auspiciante auspi = null;
		int i=0;
		while (i<traerAuspiciante().size() && auspi ==null) {
			if(traerAuspiciante().get(i).getCuit().equalsIgnoreCase(cuit)) {
				auspi = traerAuspiciante().get(i);
			}
			i++;
		}
		return auspi;
	}
	// CU 3 - boolean agregarAuspiciante (Contacto contacto, String razonSocial, String cuit, double aporteConferencia)
	public boolean agregarAuspiciante (Contacto contacto, String razonSocial, String cuit, double aporteConferencia) throws Exception {
		if(this.traerAuspiciante(cuit)!=null) throw new Exception ("Error: El cuit "+ cuit+ " del auspiciante ya esta registrado");
		int idAuspiciante =1;
		if(lstPersonas.size()!=0) {
			idAuspiciante = lstPersonas.get(lstPersonas.size()-1).getIdPersona() +1;
		}
		return(lstPersonas.add(new Auspiciante (idAuspiciante, contacto, razonSocial,cuit, aporteConferencia)));		
	}
	// CU 4 - boolean EliminarAuspiciante (String cuit)
	public boolean EliminarAuspiciante (String cuit) throws Exception {
		if(this.traerAuspiciante(cuit)==null) throw new Exception ("Error: El cuit " + cuit + " del auspiciante no se encuentra registrado para eliminar");
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != traerAuspiciante(cuit).getIdPersona()) {
			i++;
		}
		lstPersonas.remove(i);
		return true;		
	}
	// CU 5 - boolean modificarAuspiciante (String cuit, double aporteConferenciaModificado)
	public boolean modificarAuspiciante (String cuit, double aporteConferenciaModificado) throws Exception {
		if(this.traerAuspiciante(cuit)==null) throw new Exception ("Error: El cuit " + cuit + " del auspiciante no se encuentra registrado para modificar");
		Auspiciante auspi = traerAuspiciante(cuit);
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != auspi.getIdPersona()) {
			i++;
		}
		auspi.setAporteConferencia(aporteConferenciaModificado);
		lstPersonas.add(i, auspi);
		lstPersonas.remove(i+1);
		return true;		
	}
	//ORADORES
	//ORADORES
	//ORADORES
	//ORADORES
	
	// CU 6 - List<Orador> traerOrador ()
	public List<Orador> traerOrador (){
		List <Orador> lstOradores = new ArrayList<Orador>();
		int i;
		for (i=0; i<lstPersonas.size();i++) {
			if(lstPersonas.get(i) instanceof Orador) {
				lstOradores.add((Orador)lstPersonas.get(i));
			}
		}
		return (lstOradores);
	}
	// CU 7 - Orador traerOrador (long nroDocumento)
	public Orador traerOrador (long nroDocumento) {
		List <Orador> lstOradores= traerOrador();
		Orador orador = null;
		int i=0;
		while (i<traerOrador().size() && orador == null) {
			if(traerOrador().get(i).getNroDocumento() == nroDocumento) {
				orador = lstOradores.get(i);
			}
			i++;
		}
		return orador;
	}
	// CU 8 - boolean agregarOrador (Contacto contacto, String nombre, String apellido, String tipoDocumento, long nroDocumento, String areaInvestigacion)
	public boolean agregarOrador (Contacto contacto, String nombre, String apellido, String tipoDocumento, long nroDocumento, String areaInvestigacion) throws Exception {
		if(this.traerOrador(nroDocumento)!=null) throw new Exception ("Error: El numero de documento " +nroDocumento+ " ya esta registrado");
		int idOrador =1;
		if(lstPersonas.size()!=0) {
			idOrador = lstPersonas.get(lstPersonas.size()-1).getIdPersona() +1;
		}
		return(lstPersonas.add(new Orador (idOrador, contacto, nombre, apellido, tipoDocumento, nroDocumento, areaInvestigacion)));
	}
	// CU 9 - boolean EliminarOrador (long nroDocumento)
	public boolean EliminarOrador (long nroDocumento) throws Exception {
		if(this.traerOrador(nroDocumento)==null) throw new Exception ("Error: El numero de documento " + nroDocumento + " del orador no se encuentra registrado para eliminar");
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != traerOrador(nroDocumento).getIdPersona()) {
			i++;
		}
		lstPersonas.remove(i);
		return true;		
	}
	// CU 10 -  modificarOrador (long nroDocumento, String areaInvestigacion)
	public boolean modificarOrador (long nroDocumento, String areaInvestigacion) throws Exception {
		if(this.traerOrador(nroDocumento)==null) throw new Exception ("Error: El numero de documento " + nroDocumento + " del orador no se encuentra registrado para modificar");
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != traerOrador(nroDocumento).getIdPersona()) {
			i++;
		}
		Orador orador = traerOrador(nroDocumento);
		orador.setAreaInvestigacion(areaInvestigacion);
		lstPersonas.add(i, orador);
		lstPersonas.remove(i+1);
		return true;	
	}
	
	//ORGANIZADORES
	//ORGANIZADORES
	//ORGANIZADORES
	//ORGANIZADORES
	
	// CU 11 - List<Organizador> traerOrganizador ()
	public List<Organizador> traerOrganizador (){
		List <Organizador> lstOrganizadores = new ArrayList<Organizador>();
		int i;
		for (i=0; i<lstPersonas.size();i++) {
			if(lstPersonas.get(i) instanceof Organizador) {
				lstOrganizadores.add((Organizador)lstPersonas.get(i));
			}
		}
		return (lstOrganizadores);
	}
	// CU 12 - Organizador traerOrganizador (long nroDocumento)
	public Organizador traerOrganizador (long nroDocumento) {
		List <Organizador> lstOrganizadores= traerOrganizador();
		Organizador organizador = null;
		int i=0;
		while (i<traerOrganizador().size() && organizador == null) {
			if(traerOrganizador().get(i).getNroDocumento() == nroDocumento) {
				organizador = lstOrganizadores.get(i);
			}
			i++;
		}
		return organizador;
	}
	// CU 13 - boolean agregarOrganizador (Contacto contacto, String nombre, String apellido, String tipoDocumento, long nroDocumento)
	public boolean agregarOrganizador (Contacto contacto, String nombre, String apellido, String tipoDocumento, long nroDocumento) throws Exception {
		if(this.traerOrganizador(nroDocumento)!=null) throw new Exception ("Error: El numero de documento " +nroDocumento+ " ya esta registrado");
		int idOrganizador =1;
		if(lstPersonas.size()!=0) {
			idOrganizador = lstPersonas.get(lstPersonas.size()-1).getIdPersona() +1;
		}
		return(lstPersonas.add(new Organizador (idOrganizador, contacto, nombre, apellido, tipoDocumento, nroDocumento)));
	}
	// CU 14 - boolean EliminarOrganizador (long nroDocumento)
	public boolean EliminarOrganizador (long nroDocumento) throws Exception {
		if(this.traerOrganizador(nroDocumento)==null) throw new Exception ("Error: El numero de documento " + nroDocumento + " del organizador no se encuentra registrado para eliminar");
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != traerOrganizador(nroDocumento).getIdPersona()) {
			i++;
		}
		lstPersonas.remove(i);
		return true;
	}
	
	//ESPECTADOR
	//ESPECTADOR
	//ESPECTADOR
	//ESPECTADOR
	
	// CU 15 - List<Espectador> traerEspectador ()
	public List<Espectador> traerEspectador (){
		List <Espectador> lstEspectador = new ArrayList<Espectador>();
		int i;
		for (i=0; i<lstPersonas.size();i++) {
			if(lstPersonas.get(i) instanceof Espectador) {
				lstEspectador.add((Espectador)lstPersonas.get(i));
			}
		}
		return (lstEspectador);
	}
	// CU 16 - Espectador traerEspectador (long nroDocumento)
	public Espectador traerEspectador (long nroDocumento) {
		List <Espectador> lstEspectadores= traerEspectador();
		Espectador espectador = null;
		int i=0;
		while (i<traerEspectador().size() && espectador == null) {
			if(traerEspectador().get(i).getNroDocumento() == nroDocumento) {
				espectador = lstEspectadores.get(i);
			}
			i++;
		}
		return espectador;
	}
	// CU 17 - boolean agregarEspectador (Contacto contacto, String nombre, String apellido, String tipoDocumento, long nroDocumento, String nivelEstudio)
	public boolean agregarEspectador (Contacto contacto, String nombre, String apellido, String tipoDocumento, long nroDocumento, String nivelEstudio) throws Exception {
		if(this.traerEspectador(nroDocumento)!=null) throw new Exception ("Error: El numero de documento " +nroDocumento+ " ya esta registrado");
		int idEspectador =1;
		if(lstPersonas.size()!=0) {
			idEspectador = lstPersonas.get(lstPersonas.size()-1).getIdPersona() +1;
		}
		return(lstPersonas.add(new Espectador (idEspectador, contacto, nombre, apellido, tipoDocumento, nroDocumento, nivelEstudio)));
	}
	// CU 18 - boolean EliminarEspectador (long nroDocumento)
	public boolean EliminarEspectador (long nroDocumento) throws Exception {
		if(this.traerEspectador(nroDocumento)==null) throw new Exception ("Error: El numero de documento " + nroDocumento + " del espectador no se encuentra registrado para eliminar");
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != traerEspectador(nroDocumento).getIdPersona()) {
			i++;
		}
		lstPersonas.remove(i);
		return true;
	}
	// CU 19 - boolean modificarEspectador
	public boolean modificarEspectador (long nroDocumento, String nivelEstudio) throws Exception {
		if(this.traerEspectador(nroDocumento)==null) throw new Exception ("Error: El numero de documento " + nroDocumento + " del espectador no se encuentra registrado para modificar");
		int i=0;
		while (lstPersonas.get(i).getIdPersona() != traerEspectador(nroDocumento).getIdPersona()) {
			i++;
		}
		Espectador espectador = traerEspectador(nroDocumento);
		espectador.setNivelEstudio(nivelEstudio);
		lstPersonas.add(i, espectador);
		lstPersonas.remove(i+1);
		return true;		
	}
	
	//CONFERENCIAS
	//CONFERENCIAS
	//CONFERENCIAS
	//CONFERENCIAS
	
	// CU 20 - Conferencia traerConferencia (String titulo)
	public Conferencia traerConferencia (String titulo) {
		Conferencia confe = null;
		int i=0;
		while (i<lstConferencias.size() && confe == null) {
			if(lstConferencias.get(i).getTitulo().equalsIgnoreCase(titulo)) {
				confe = lstConferencias.get(i);
			}
			i++;
		}
		return confe;
	}
	// CU 21 - boolean agregarConferencia (String titulo, LocalDate diaConferencia, Sala sala)
	public boolean agregarConferencia (String titulo, LocalDate diaConferencia, Sala sala) throws Exception {
		if(this.traerConferencia(titulo)!=null) throw new Exception ("Error: El titulo " + titulo + " ya esta registrado");
		if(diaConferencia.isAfter(fechaFin)) throw new Exception ("Error: la fecha ingresada no es correcta");
		if(diaConferencia.isBefore(fechaInicio)) throw new Exception ("Error: la fecha ingresada no es correcta");
		int idConferencia =1;
		if(lstConferencias.size()!=0) {
			idConferencia = lstConferencias.get(lstConferencias.size()-1).getIdConferencia() +1;
		}
		return(lstConferencias.add(new Conferencia (idConferencia, titulo, diaConferencia,sala)));		
	}
	// CU 22 - boolean EliminarConferencia (String titulo)
	public boolean EliminarConferencia (String titulo) throws Exception {
		if(this.traerConferencia(titulo)==null) throw new Exception ("Error: El titulo " + titulo + " de la conferencia no se encuentra registrado para eliminar");
		int i=0;
		while (!lstConferencias.get(i).getTitulo().equalsIgnoreCase(titulo)) {
			i++;
		}
		lstConferencias.remove(i);
		return true;		
	}
	// CU 23 - modificarConferencia (String titulo, String tituloNuevo, LocalDate diaConferencia, Sala sala)
	public boolean modificarConferencia (String titulo, String tituloNuevo, LocalDate diaConferencia, Sala sala) throws Exception {
		if(this.traerConferencia(titulo)==null) throw new Exception ("Error: El titulo " + titulo + " de la conferencia no se encuentra registrado para modificar");
		if(diaConferencia.isAfter(fechaFin)) throw new Exception ("Error: la fecha ingresada no es correcta");
		if(diaConferencia.isBefore(fechaInicio)) throw new Exception ("Error: la fecha ingresada no es correcta");
		int i=0;
		while (!lstConferencias.get(i).getTitulo().equalsIgnoreCase(titulo)) {
			i++;
		}
		lstConferencias.get(i).setTitulo(tituloNuevo);
		lstConferencias.get(i).setDiaConferencia(diaConferencia);
		lstConferencias.get(i).setSala(sala);
		return true;		
	}
	
	//SALAS
	//SALAS
	//SALAS
	//SALAS
	
	// CU 24 - Sala traerSala (int idSala)
	public Sala traerSala (int idSala) {
		Sala sala = null;
		int i=0;
		while (i<lstSalas.size() && sala == null) {
			if(lstSalas.get(i).getIdSala() == idSala) {
				sala = lstSalas.get(i);
			}
			i++;
		}
		return sala;
	}
	// CU 25 - boolean agregarSala (String descripcion, int capacidad)
	public boolean agregarSala (String descripcion, int capacidad){
		int idSala =1;
		if(lstSalas.size()!=0) {
			idSala = lstSalas.get(lstSalas.size()-1).getIdSala() +1;
		}
		return(lstSalas.add(new Sala (idSala, descripcion, capacidad)));		
	}
	// CU 26 - boolean EliminarSala (int idSala)
	public boolean EliminarSala (int idSala) throws Exception {
		if(this.traerSala(idSala)==null) throw new Exception ("Error: El id " + idSala + " de la sala no se encuentra registrado para eliminar");
		int i=0;
		while (lstSalas.get(i).getIdSala() != idSala) {
			i++;
		}
		lstSalas.remove(i);
		return true;		
	}
	// CU 27 - boolean modificarSala (int idSala, String descripcion, int capacidad)
	public boolean modificarSala (int idSala, String descripcion, int capacidad) throws Exception {
		if(this.traerSala(idSala)==null) throw new Exception ("Error: El id " + idSala + " de la sala no se encuentra registrado para modificar");
		int i=0;
		while (lstSalas.get(i).getIdSala() != idSala) {
			i++;
		}
		lstSalas.get(i).setDescripcion(descripcion);
		lstSalas.get(i).setCapacidad(capacidad);
		return true;		
	}
	
	//ENTRADAS
	//ENTRADAS
	//ENTRADAS
	//ENTRADAS
	
	// CU 28 - Entrada traerEntrada (String codigo)
	public Entrada traerEntrada (String codigo) {
		Entrada entrada = null;
		int i=0;
		while (i<lstEntradas.size() && entrada==null) {
			if(lstEntradas.get(i).getCodigo().equalsIgnoreCase(codigo)) {
				entrada = lstEntradas.get(i);
			}
			i++;
		}
		return entrada;
	}
	// CU 29 - int contadorEntradasPorEspectaculo (Conferencia conferencia)
	public int contadorEntradasPorEspectaculo (Conferencia conferencia) {
		int suma = 0;
		for (int i=0; i<lstEntradas.size(); i++) {
			if (lstEntradas.get(i).getConferencia().getTitulo().equalsIgnoreCase(conferencia.getTitulo())) {
				suma++;
			}
		}
		return suma;
	}
	// CU 30 - boolean agregarEntrada (String codigo, double precioEntrada, Espectador espectador, Conferencia conferencia)
	public boolean agregarEntrada (String codigo, double precioEntrada, Espectador espectador, Conferencia conferencia) throws Exception {
		if(this.traerEntrada(codigo)!=null) throw new Exception ("Error: El codigo " + codigo + " ya esta registrado");
		if( !(contadorEntradasPorEspectaculo(conferencia) < conferencia.getSala().getCapacidad())) throw new Exception ("Error: ya no hay mas cupos para la conferencia");
		int idEntrada =1;
		if(lstEntradas.size()!=0) {
			idEntrada = lstEntradas.get(lstEntradas.size()-1).getIdEntrada() +1;
		}
		int cont=0;
		for (int i=0; i<lstEntradas.size();i++) {
			if(lstEntradas.get(i).getEspectador().getNroDocumento()==espectador.getNroDocumento()) {
				cont ++;
			}
		}
		if (cont == 2) {
			precioEntrada=0;
		}
		return(lstEntradas.add(new Entrada (idEntrada, codigo, LocalDate.now(), LocalTime.now(), precioEntrada, espectador, conferencia)));		
	}
	//punto 7
	//punto 7
	//punto 7
	//punto 7
	
	// CU 31 - Entrada traerEntrada (long documento)
	public Entrada traerEntrada (long documento) {
		Entrada entrada = null;
		int i=0;
		while (i<lstEntradas.size() && entrada == null) {
			if(lstEntradas.get(i).getEspectador().getNroDocumento()== documento) {
				entrada = lstEntradas.get(i);
			}
			i++;
		}
		return entrada;
	}
	// CU 32 - double calcularPrecioPorEspectador (Espectador espectador)
	public double calcularPrecioPorEspectador (Espectador espectador) throws Exception {
		if(this.traerEntrada(espectador.getNroDocumento())==null) throw new Exception ("Error: El espectador: " + espectador + " es invalido");
		double suma = ingreso;
		for (int i=0; i<lstEntradas.size();i++) {
			if(lstEntradas.get(i).getEspectador().getNroDocumento() == espectador.getNroDocumento()) {
				suma = suma + lstEntradas.get(i).getPrecioEntrada();
			}
		}
		return suma;
	}
	
	//punto 8
	//punto 8
	//punto 8
	//punto 8
	
	// CU 33 - List <Conferencia> traerConferencia (LocalDate dia)
	public List <Conferencia> traerConferencia (LocalDate dia) {
		List <Conferencia> listaTraer= new ArrayList<Conferencia>();
		for (int i=0; i< lstConferencias.size(); i++) {
			if(lstConferencias.get(i).getDiaConferencia().isEqual(dia)) {
				listaTraer.add(lstConferencias.get(i));
			}
		}
		return (listaTraer);	
	}
	
	//punto 9
	//punto 9
	//punto 9
	//punto 9
	
	// CU 34 - List<Exposicion> exposicionPorOrganizador (Organizador organizador)
	public List<Exposicion> exposicionPorOrganizador (Organizador organizador) throws Exception {
		if(this.traerOrganizador(organizador.getNroDocumento())==null) throw new Exception ("Error: El organizador " + organizador + " no se encuentra registrado");
		List<Exposicion> exposicion = new ArrayList<Exposicion>();
		int i=0;
		while (traerOrganizador().get(i).getIdPersona() != traerOrganizador(organizador.getNroDocumento()).getIdPersona()) {
			i++;
		}
		Organizador orga = traerOrganizador().get(i);
		for (int j=0; j<orga.getLstConferencia().size(); j++) {
			for (int k=0; k<orga.getLstConferencia().get(j).getLstExposiciones().size(); k++) {
				exposicion.add(orga.getLstConferencia().get(j).getLstExposiciones().get(k));
			}
		}
		return exposicion;
	}

	//punto 10
	//punto 10
	//punto 10
	//punto 10
	
	// CU 35 - double saldoConferencia (Conferencia conferencia)
	public double saldoConferencia (Conferencia conferencia) throws Exception {
		if(this.traerConferencia(conferencia.getTitulo())==null) throw new Exception ("Error: La conferencia " + conferencia + " no esta registrado");
		double suma = conferencia.calcularCostoReal();
		for (int i=0; i<lstEntradas.size(); i++) {
			if(lstEntradas.get(i).getConferencia().getTitulo().equalsIgnoreCase(conferencia.getTitulo())) {
				suma = suma + lstEntradas.get(i).getPrecioEntrada();
			}
		}
		return suma;
	}
	
	//punto 12
	//punto 12
	//punto 12
	//punto 12
	
	// CU 36 - List <Ranking> traerRankingNivelEstudio ()
	public List <Ranking> traerRankingNivelEstudio () {
		List <Ranking> lstRanking = new ArrayList<Ranking>();
		List <Espectador> lstespe = this.traerEspectador();
		for (int i=0; i<lstespe.size();i++) {
			boolean flag = false;
			int j=0;
			while(j<lstRanking.size() && flag == false) {
				if(lstespe.get(i).getNivelEstudio().equalsIgnoreCase(lstRanking.get(j).getTexto())) {
					lstRanking.get(j).setNumero(lstRanking.get(j).getNumero()+1);
					flag = true;
				}
				j++;
			}
			if(flag == false) {
				lstRanking.add(new Ranking (lstespe.get(i).getNivelEstudio(), 1));
			}
		}
		return lstRanking;
	}
	
	//punto 13
	//punto 13
	//punto 13
	//punto 13
	
	// CU 37 - List <Ranking> traerRankingButacasVacias ()
	public List <Ranking> traerRankingButacasVacias () {
		List <Ranking> lstRanking = new ArrayList<Ranking>();
		for (int i=0; i<lstConferencias.size();i++) {
			for(int j=0; j<lstConferencias.get(i).getLstExposiciones().size(); j++) {
				if(lstConferencias.get(i).getLstExposiciones().get(j) instanceof Presencial) {
					Presencial prese = (Presencial) lstConferencias.get(i).getLstExposiciones().get(j);
					lstRanking.add(new Ranking ("Conferencia: " + lstConferencias.get(i).getTitulo() + " Exposicion: " + prese.getIdExposicion() , 
					lstConferencias.get(i).getSala().getCapacidad() - prese.getLstEspectador().size()));
				}
			}
		}
		return lstRanking;
	}

	//punto 14
	//punto 14
	//punto 14
	//punto 14
	
	// CU 38 - double calcularSaldoFinal ()
	public double calcularSaldoFinal () {
		double suma = 0;
		for(int i=0; i<lstConferencias.size(); i++){
			suma = suma + traerConferencia(lstConferencias.get(i).getTitulo()).calcularCostoReal();
			for (int j=0; j<lstEntradas.size(); j++) {
				if(lstEntradas.get(j).getConferencia().getTitulo()==lstConferencias.get(i).getTitulo()) {
					suma = suma + lstEntradas.get(j).getPrecioEntrada();
				}
			}
		}
		for (int i=0; i<traerEspectador().size();i++) {
			suma = suma + ingreso; 
		}
		return suma;
	}
}
