package modelo;
import java.util.ArrayList;
import java.util.List;

import modelo.Conferencia;

public class Organizador extends PersonaFisica {
	private List<Conferencia> lstConferencias;
	//constructor

	public Organizador(int idPersona, Contacto contacto, String nombre, String apellido, String tipoDocumento, long dni) {
		super(idPersona, contacto, nombre, apellido, tipoDocumento, dni);
		this.lstConferencias = new ArrayList<Conferencia>();
	}
	//getter y setter

	public List<Conferencia> getLstConferencia() {
		return lstConferencias;
	}

	public void setLstConferencia(List<Conferencia> lstConferencias) {
		this.lstConferencias = lstConferencias;
	}
	//toString

	@Override
	public String toString() {
		return "Organizador [idPersona=" + idPersona +", "+ contacto.toString() + ", nombre=" + nombre + ", apellido=" + apellido + 
				", tipoDocumento=" + tipoDocumento + ", nroDocumento=" + nroDocumento + " lstConferencias=" + lstConferencias + "]";
	}	
	public boolean agregarConferencia (Conferencia conferencia) {
		return(lstConferencias.add(conferencia));
	}
}
