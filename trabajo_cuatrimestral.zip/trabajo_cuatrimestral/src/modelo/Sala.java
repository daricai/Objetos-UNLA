package modelo;

public class Sala {
	private int idSala;
	private String descripcion;
	private int capacidad;
	//constructor
	public Sala(int idSala, String descripcion, int capacidad) {
		super();
		this.idSala = idSala;
		this.descripcion = descripcion;
		this.capacidad = capacidad;
	}
	//getter y setter
	public int getIdSala() {
		return idSala;
	}
	public void setIdSala(int idSala) {
		this.idSala = idSala;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public int getCapacidad() {
		return capacidad;
	}
	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
	//toString
	@Override
	public String toString() {
		return "Sala [idSala=" + idSala + ", descripcion=" + descripcion + ", capacidad=" + capacidad + "]";
	}
	
	
}
