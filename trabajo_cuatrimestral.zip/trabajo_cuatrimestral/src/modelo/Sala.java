package modelo;

public class Sala {
	private String descripcion;
	private int capacidad;
	//constructor
	public Sala(String descripcion, int capacidad) {
		super();
		this.descripcion = descripcion;
		this.capacidad = capacidad;
	}
	//getter y setter
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public int getCapacidad() {
		return capacidad;
	}
	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
	//toString
	@Override
	public String toString() {
		return "Sala [descripcion=" + descripcion + ", capacidad=" + capacidad + "]";
	}
	
}
