package modelo;
import modelo.Sala;
import modelo.Exposicion;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Conferencia {
	private int idConferencia;
	private String titulo;
	private LocalDate diaConferencia;
	private Sala sala;
	private List<Exposicion> lstExposiciones;
	private List<Auspiciante> lstAuspiciantes;
	//constructor
	public Conferencia(int idConferencia, String titulo, LocalDate diaConferencia, Sala sala) {
		super();
		this.idConferencia = idConferencia;
		this.titulo = titulo;
		this.diaConferencia = diaConferencia;
		this.sala = sala;
		this.lstExposiciones = new ArrayList<Exposicion>();
		this.lstAuspiciantes = new ArrayList<Auspiciante>();
	}
	//getter y setter
	public int getIdConferencia() {
		return idConferencia;
	}
	public void setIdConferencia(int idConferencia) {
		this.idConferencia = idConferencia;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public LocalDate getDiaConferencia() {
		return diaConferencia;
	}
	public void setDiaConferencia(LocalDate diaConferencia) {
		this.diaConferencia = diaConferencia;
	}
	public Sala getSala() {
		return sala;
	}
	public void setSala(Sala sala) {
		this.sala = sala;
	}
	public List<Exposicion> getLstExposiciones() {
		return lstExposiciones;
	}
	public void setLstExposiciones(List<Exposicion> lstExposiciones) {
		this.lstExposiciones = lstExposiciones;
	}
	public List<Auspiciante> getLstAuspiciantes() {
		return lstAuspiciantes;
	}
	public void setLstAuspiciantes(List<Auspiciante> lstAuspiciantes) {
		this.lstAuspiciantes = lstAuspiciantes;
	}
	//toString
	@Override
	public String toString() {
		return "Conferencia [idConferencia=" + idConferencia + ", titulo=" + titulo + ", diaConferencia="
				+ diaConferencia + ", sala=" + sala + ", lstExposiciones=" + lstExposiciones + ", lstAuspiciantes="
				+ lstAuspiciantes + "]";
	}
	
	// CU  - List<Presencial> traerExposicionPresencial ()
	public List<Presencial> traerExposicionPresencial (){
		List <Presencial> lstExposicionPresencial= new ArrayList<Presencial>();
		int i;
		for (i=0; i<lstExposiciones.size();i++) {
			if(lstExposiciones.get(i) instanceof Presencial) {
				lstExposicionPresencial.add((Presencial)lstExposiciones.get(i));
			}
		}
		return (lstExposicionPresencial);
	}
	// CU  - Presencial traerExposicionPresencial (int idExposicion)
	public Presencial traerExposicionPresencial (int idExposicion) {
		Presencial prese = null;
		int i=0;
		while (i<traerExposicionPresencial().size() && prese ==null) {
			if(traerExposicionPresencial().get(i).getIdExposicion() == idExposicion) {
				prese = traerExposicionPresencial().get(i);
			}
			i++;
		}
		return prese;
	}
	// CU  - public boolean agregarExposicionPresencial (Orador orador, double costoRealizacion, LocalTime horaInicio, LocalTime horaFin)
	public boolean agregarExposicionPresencial (Orador orador, double costoRealizacion, LocalTime horaInicio, LocalTime horaFin) throws Exception {
		if(horaInicio.isAfter(horaFin)) throw new Exception ("Error: la hora de inicio nunca puede ser despues de la hora de fin");
		for (int i=0; i<traerExposicionPresencial().size(); i++) {
			if(!horaInicio.isAfter(traerExposicionPresencial().get(i).getHoraFin()) && !horaFin.isBefore(traerExposicionPresencial().get(i).getHoraInicio()))throw new Exception ("Error: no se puedo utilizar esos horarios, ya que se superponen con otra exposicion");
		}
		int idExposicion =1;
		if(lstExposiciones.size()!=0) {
			idExposicion = lstExposiciones.get(lstExposiciones.size()-1).getIdExposicion() +1;
		}
		lstExposiciones.add(new Presencial (idExposicion, titulo, orador, costoRealizacion, horaInicio, horaFin));
		return true;
	}
	// CU  - List<Virtual> traerExposicionVirtual ()
	public List<Virtual> traerExposicionVirtual (){
		List <Virtual> lstExposicionVirtual= new ArrayList<Virtual>();
		int i;
		for (i=0; i<lstExposiciones.size();i++) {
			if(lstExposiciones.get(i) instanceof Virtual) {
				lstExposicionVirtual.add((Virtual)lstExposiciones.get(i));
			}
		}
		return (lstExposicionVirtual);
	}
	// CU  - boolean agregarExposicionVirtual (Orador orador, double costoRealizacion, LocalTime horaInicio, LocalTime horaFin, String medioDifusion, String url)
	public boolean agregarExposicionVirtual (Orador orador, double costoRealizacion, LocalTime horaInicio, LocalTime horaFin, String medioDifusion, String url) throws Exception {
		if(horaInicio.isAfter(horaFin)) throw new Exception ("Error: la hora de inicio nunca puede ser despues de la hora de fin");
		int idExposicion =1;
		if(lstExposiciones.size()!=0) {
			idExposicion = lstExposiciones.get(lstExposiciones.size()-1).getIdExposicion() +1;
		}
		return(lstExposiciones.add(new Virtual (idExposicion, titulo, orador, costoRealizacion, horaInicio, horaFin, medioDifusion, url)));
	}
	// CU  - boolean agregarAuspiciante (Auspiciante auspiciante)
	public boolean agregarAuspiciante (Auspiciante auspiciante) {
		return(lstAuspiciantes.add(auspiciante));
	}
	//10)
	// CU  - double calcularCostoReal()
	public double calcularCostoReal() {
		double suma=0;
		for (int i=0; i<lstAuspiciantes.size(); i++) {
			suma= suma + lstAuspiciantes.get(i).getAporteConferencia();
		}
		for (int i=0; i<lstExposiciones.size(); i++) {
			suma= suma - lstExposiciones.get(i).getCostoRealizacion();
		}
		return suma;
	}
	
}	