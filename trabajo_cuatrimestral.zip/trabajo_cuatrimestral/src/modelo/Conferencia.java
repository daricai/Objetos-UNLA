package modelo;
import modelo.Sala;
import modelo.Exposicion;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Conferencia {
	private int idConferencia;
	private String titulo;
	private LocalDate diaConferencia;
	private Sala sala;
	private List<Exposicion> lstExposiciones;
	private List<Auspiciante> lstAuspiciantes;
	//constructor
	public Conferencia(int idConferencia, String titulo, LocalDate diaConferencia, Sala sala) {
		super();
		this.idConferencia = idConferencia;
		this.titulo = titulo;
		this.diaConferencia = diaConferencia;
		this.sala = sala;
		this.lstExposiciones = new ArrayList<Exposicion>();
		this.lstAuspiciantes = new ArrayList<Auspiciante>();
	}
	//getter y setter
	public int getIdConferencia() {
		return idConferencia;
	}
	public void setIdConferencia(int idConferencia) {
		this.idConferencia = idConferencia;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public LocalDate getDiaConferencia() {
		return diaConferencia;
	}
	public void setDiaConferencia(LocalDate diaConferencia) {
		this.diaConferencia = diaConferencia;
	}
	public Sala getSala() {
		return sala;
	}
	public void setSala(Sala sala) {
		this.sala = sala;
	}
	public List<Exposicion> getLstExposiciones() {
		return lstExposiciones;
	}
	public void setLstExposiciones(List<Exposicion> lstExposiciones) {
		this.lstExposiciones = lstExposiciones;
	}
	public List<Auspiciante> getLstAuspiciantes() {
		return lstAuspiciantes;
	}
	public void setLstAuspiciantes(List<Auspiciante> lstAuspiciantes) {
		this.lstAuspiciantes = lstAuspiciantes;
	}
	//toString
	@Override
	public String toString() {
		return "Conferencia [idConferencia=" + idConferencia + ", titulo=" + titulo + ", diaConferencia="
				+ diaConferencia + ", sala=" + sala + ", lstExposiciones=" + lstExposiciones + ", lstAuspiciantes="
				+ lstAuspiciantes + "]";
	}
}	