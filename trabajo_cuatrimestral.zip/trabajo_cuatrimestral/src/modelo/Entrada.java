package modelo;
import java.time.LocalDate;
import java.time.LocalTime;
import modelo.Espectador;

public class Entrada {
	private int idEntrada;
	private int codigo;
	private LocalDate fechaCompra;
	private LocalTime horaCompra;
	private double precioEntrada;
	private Espectador espectador;
	private Conferencia conferencia;
	//constructor
	public Entrada(int idEntrada, int codigo, LocalDate fechaCompra, LocalTime horaCompra, double precioEntrada,
			Espectador espectador, Conferencia conferencia) {
		super();
		this.idEntrada = idEntrada;
		this.codigo = codigo;
		this.fechaCompra = fechaCompra;
		this.horaCompra = horaCompra;
		this.precioEntrada = precioEntrada;
		this.espectador = espectador;
		this.conferencia = conferencia;
	}
	//getter y setter
	public int getIdEntrada() {
		return idEntrada;
	}
	public void setIdEntrada(int idEntrada) {
		this.idEntrada = idEntrada;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public LocalDate getFechaCompra() {
		return fechaCompra;
	}
	public void setFechaCompra(LocalDate fechaCompra) {
		this.fechaCompra = fechaCompra;
	}
	public LocalTime getHoraCompra() {
		return horaCompra;
	}
	public void setHoraCompra(LocalTime horaCompra) {
		this.horaCompra = horaCompra;
	}
	public double getPrecioEntrada() {
		return precioEntrada;
	}
	public void setPrecioEntrada(double precioEntrada) {
		this.precioEntrada = precioEntrada;
	}
	public Espectador getEspectador() {
		return espectador;
	}
	public void setEspectador(Espectador espectador) {
		this.espectador = espectador;
	}
	public Conferencia getConferencia() {
		return conferencia;
	}
	public void setConferencia(Conferencia conferencia) {
		this.conferencia = conferencia;
	}
	//toString
	@Override
	public String toString() {
		return "Entrada [idEntrada=" + idEntrada + ", codigo=" + codigo + ", fechaCompra=" + fechaCompra
				+ ", horaCompra=" + horaCompra + ", precioEntrada=" + precioEntrada + ", espectador=" + espectador
				+ ", conferencia=" + conferencia + "]";
	}	
}
