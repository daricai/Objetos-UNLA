package modelo;
import java.time.LocalDate;
import java.time.LocalTime;
import modelo.Espectador;

public class Entrada {
	private int idEntrada;
	private String codigo;
	private LocalDate fechaCompra;
	private LocalTime horaCompra;
	private double precioEntrada;
	private Espectador espectador;
	private Conferencia conferencia;
	//constructor
	public Entrada(int idEntrada, String codigo, LocalDate fechaCompra, LocalTime horaCompra, double precioEntrada,
			Espectador espectador, Conferencia conferencia) throws Exception{
		super();
		this.idEntrada = idEntrada;
		this.setCodigo(codigo) ;
		this.fechaCompra = fechaCompra;
		this.horaCompra = horaCompra;
		this.precioEntrada = precioEntrada;
		this.espectador = espectador;
		this.conferencia = conferencia;
	}
	//getter y setter
	public int getIdEntrada() {
		return idEntrada;
	}
	public void setIdEntrada(int idEntrada) {
		this.idEntrada = idEntrada;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) throws Exception {
		if(!this.esCodIngresoValido(codigo)) throw new Exception ("Error: El codigo " + codigo + " es incorrecto");
		this.codigo = codigo;
	}
	public LocalDate getFechaCompra() {
		return fechaCompra;
	}
	public void setFechaCompra(LocalDate fechaCompra) {
		this.fechaCompra = fechaCompra;
	}
	public LocalTime getHoraCompra() {
		return horaCompra;
	}
	public void setHoraCompra(LocalTime horaCompra) {
		this.horaCompra = horaCompra;
	}
	public double getPrecioEntrada() {
		return precioEntrada;
	}
	public void setPrecioEntrada(double precioEntrada) {
		this.precioEntrada = precioEntrada;
	}
	public Espectador getEspectador() {
		return espectador;
	}
	public void setEspectador(Espectador espectador) {
		this.espectador = espectador;
	}
	public Conferencia getConferencia() {
		return conferencia;
	}
	public void setConferencia(Conferencia conferencia) {
		this.conferencia = conferencia;
	}
	//toString
	@Override
	public String toString() {
		return "Entrada [idEntrada=" + idEntrada + ", codigo=" + codigo + ", fechaCompra=" + fechaCompra
				+ ", horaCompra=" + horaCompra + ", precioEntrada=" + precioEntrada + ", espectador=" + espectador
				+ ", conferencia=" + conferencia + "]";
	}	
//CU - 	 int calcularDigitoVerificador (String codIngreso)
	public int calcularDigitoVerificador (String codIngreso) {
		int suma=0;
		int i;
		for (i=0; i<3; i++) {
			suma = suma + (Character.getNumericValue(codIngreso.charAt(i)));
		}
		for (i=3; i<6; i++) {
			suma = suma + ((Character.getNumericValue(codIngreso.charAt(i)) * 4));
		}
		i=0;
		while (suma % 10 != 0){
			i++;
			suma++;
		}
		return (i);
	}
//CU - boolean esCodIngresoValido (String codIngreso)
	public boolean esCodIngresoValido (String codIngreso) {
		boolean retorno = false;
		if (Funciones.esCadenaNros(codIngreso)) {
			if(codIngreso.length() == 7) {
				if(calcularDigitoVerificador(codIngreso) == Character.getNumericValue(codIngreso.charAt(6))) {
					retorno = true;
				}
			}
		}
		return retorno;
	}
}
