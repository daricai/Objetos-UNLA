package modelo;

public class Contacto {
	private String mail;
	private String telefono;
	//constructor
	public Contacto(String mail, String telefono) {
		super();
		this.mail = mail;
		this.telefono = telefono;
	}
	//getter y setter
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	//toString
	@Override
	public String toString() {
		return "Contacto [mail=" + mail + ", telefono=" + telefono + "]";
	}
}
