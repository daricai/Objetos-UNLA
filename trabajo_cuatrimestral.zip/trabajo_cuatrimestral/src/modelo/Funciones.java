package modelo;
import java.time.LocalDate;
import java.time.LocalTime;
public class Funciones {
	
	public static boolean esBisiesto (int anio) {
		/*if(anio % 4 == 0) {
			if(anio % 100 !=0 || anio % 400==0) {
				return true;
			}
		}
		return false;*/
		return ((anio % 4 == 0) && (anio % 100 != 0 || anio % 400 ==0)); 
	}
	public static String traerFechaCorta (LocalDate fecha) {
		String fechaCorta ="";
		if(fecha.getDayOfMonth()>9) {
			fechaCorta = fechaCorta + String.valueOf(fecha.getDayOfMonth()) + "/";
		}
		else {
			fechaCorta = fechaCorta +"0"+ String.valueOf(fecha.getDayOfMonth()) + "/";
		}
		if(fecha.getMonthValue()>9) {
			fechaCorta = fechaCorta + String.valueOf(fecha.getMonthValue()) + "/";
		}
		else {
			fechaCorta = fechaCorta +"0" + String.valueOf(fecha.getMonthValue()) + "/";
		}
		if(fecha.getYear()>=1000) {
			fechaCorta = fechaCorta + String.valueOf(fecha.getYear());
		}
		else {
			if(fecha.getYear()>=100) {
				fechaCorta = fechaCorta +"0"+ String.valueOf(fecha.getYear());
			}
			else {
				fechaCorta = fechaCorta +"00"+ String.valueOf(fecha.getYear());
				
			}
		}
		return fechaCorta;
	}
	public static String traerHoraCorta(LocalTime hora) {
		String horaCorta ="";
		if(hora.getHour()>9) {
			horaCorta = horaCorta + String.valueOf(hora.getHour()) + ":";
		}
		else {
			horaCorta = horaCorta +"0"+ String.valueOf(hora.getHour()) + ":";
		}
		if(hora.getMinute()>9) {
			horaCorta = horaCorta + String.valueOf(hora.getMinute());
		}
		else {
			horaCorta = horaCorta +"0"+ String.valueOf(hora.getMinute());
		}
		return horaCorta;
	}
	public static boolean esDiaHabil (LocalDate fecha) {
		int d= fecha.getDayOfWeek().getValue();
		return ((d>=1) && (d<=5));
	}
	public static String traerDiaDeLaSemana (LocalDate fecha) {
		String dia="";
		switch(fecha.getDayOfWeek().getValue()) {
		case 1:
			dia= "Lunes";
			break;
		case 2:
			dia= "Martes";
			break;
		case 3:
			dia= "Miercoles";
			break;
		case 4:
			dia= "Jueves";
			break;
		case 5:
			dia= "Viernes";
			break;
		case 6:
			dia= "Sabado";
			break;
		case 7:
			dia= "Domingo";
			break;
		}
		return dia;
	}
	public static String traerMesEnLetras (LocalDate fecha) {
		String mes="";
		switch(fecha.getMonthValue()) {
		case 1:
			mes= "Enero";
			break;
		case 2:
			mes= "Febrero";
			break;
		case 3:
			mes= "Marzo";
			break;
		case 4:
			mes= "Abril";
			break;
		case 5:
			mes= "Mayo";
			break;
		case 6:
			mes= "Junio";
			break;
		case 7:
			mes= "Julio";
			break;
		case 8:
			mes= "Agosto";
			break;
		case 9:
			mes= "Septiembre";
			break;
		case 10:
			mes= "Octubre";
			break;
		case 11:
			mes= "Noviembre";
			break;
		case 12:
			mes= "Diciembre";
			break;
		}
		return mes;
	}
	public static String traerFechaLarga (LocalDate fecha) {
		return (traerDiaDeLaSemana(fecha)+ " " + fecha.getDayOfMonth()+" de "+traerMesEnLetras(fecha) + " del "+fecha.getYear());
	}
	public static int traerCantDiasDeUnMes (int a�o, int mes)throws Exception {
		if(mes <1 || mes>12) throw new Exception("Error: el mes numero "+ mes+ " no corresponde a un mes valido"); 
		return (LocalDate.of(a�o, mes, 01).lengthOfMonth());
	}
	public static double aproximar2Decimal (double valor) {
		String n = String.valueOf(valor-(int)valor);
		if(n.length()>4) {
			if(Double.parseDouble(Character.toString(n.charAt(4))) >=5) {
				double num = valor + 0.01;
				n= String.valueOf(num-(int)num);
				n = String.valueOf((int)num) + n.charAt(1) + n.charAt(2)+n.charAt(3);
			}
			else {
				n = String.valueOf((int)valor) + n.charAt(1) + n.charAt(2)+n.charAt(3);
			}
		}
		else {
			n = String.valueOf(valor);
		}
		return(Double.parseDouble(n));
	}
	
	public static boolean esNumero (char c) {
		return (Character.getNumericValue(c)>=0 && Character.getNumericValue(c)<10);
	}
	public static boolean esLetra (char c) {
		return (Character.getNumericValue(c)>=10 && Character.getNumericValue(c)<36 || Character.getNumericValue(c)==-1);
	}
	public static boolean esCadenaNros (String cadena) {
		int i=0;
		while (i<cadena.length() && esNumero(cadena.charAt(i))) {
			i++;
		}
		if (i>=cadena.length()) {
			return true;
		}
		else {
			return false;
		}
		
	}
	public static boolean esCadenaLetras (String cadena) {
		int i=0;
		while (i<cadena.length() && esLetra(cadena.charAt(i))) {
			i++;
		}
		if (i>=cadena.length()) {
			return true;
		}
		else {
			return false;
		}
		
	}
	public static double convertirADouble (int n) {
		return ((double)n);
	}
	public static boolean validarSexo (char sexo) {
		return (Character.getNumericValue(sexo)==15 || Character.getNumericValue(sexo)==22);
	}
	public static boolean validarCuilHombre (String cuil) {
		boolean ok = false;
		if(cuil.length()==13) {
			if(Character.getNumericValue(cuil.charAt(0))==2 && cuil.charAt(2)=='-' && cuil.charAt(11)=='-') {
				int [] arrayInt = {5,4,0,3,2,7,6,5,4,3,2,0,0};
				int v1=0;
				int v2, v3, digito2;
				int i=0;
				while ((i < cuil.length()) && (esNumero(cuil.charAt(i)) || cuil.charAt(i)=='-' )) {
					if (esNumero(cuil.charAt(i))) {
						v1=v1+(arrayInt[i]*Character.getNumericValue(cuil.charAt(i)));
					}
					i++;
				}
				if (i>= cuil.length()) {
					v2=v1 %11;
					if (v2==0) {
						v3=0;
						digito2= 3;
					}
					else {
						if(v2==1) {
							v3 = 9;
							digito2= 3;
						}
						else {
							v3= 11- v2;
							digito2=0;
						}
					}
					if(Character.getNumericValue(cuil.charAt(1))==digito2 && Character.getNumericValue(cuil.charAt(12))==v3) {
						ok = true;
					}
				}
			}
		}
		return ok;
	}
	public static boolean validarCuilMujer (String cuil) {
		boolean ok = false;
		if(cuil.length()==13) {
			if(Character.getNumericValue(cuil.charAt(0))==2 && cuil.charAt(2)=='-' && cuil.charAt(11)=='-') {
				int [] arrayInt = {5,4,0,3,2,7,6,5,4,3,2,0,0};
				int v1=0;
				int v2, v3, digito2;
				int i=0;
				while ((i < cuil.length()) && (esNumero(cuil.charAt(i)) || cuil.charAt(i)=='-' )) {
					if (esNumero(cuil.charAt(i))) {
						v1=v1+(arrayInt[i]*Character.getNumericValue(cuil.charAt(i)));
					}
					i++;
				}
				if (i>= cuil.length()) {
					v2=v1 %11;
					if (v2==0) {
						v3=0;
						digito2= 3;
					}
					else {
						if(v2==1) {
							v3 = 4;
							digito2= 3;
						}
						else {
							v3= 11- v2;
							digito2=7;
						}
					}
					if(Character.getNumericValue(cuil.charAt(1))==digito2 && Character.getNumericValue(cuil.charAt(12))==v3) {
						ok = true;
					}
				}
			}
		}
		return ok;
	}
	public static boolean validarDominio (String dominio) {
		boolean ok = false;
		if(dominio.length()==7) {
			if(esLetra(dominio.charAt(0)) && (esLetra(dominio.charAt(1)))){
				if(esNumero(dominio.charAt(2)) && esNumero(dominio.charAt(3)) && esNumero(dominio.charAt(4))) {
					if(esLetra(dominio.charAt(5)) && (esLetra(dominio.charAt(6)))) {
						ok=true;
					}
				}
			}
		}
		return (ok);
	}
}