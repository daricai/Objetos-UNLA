package modelo;

public class Orador extends PersonaFisica {
	private String areaInvestigacion;
	//constructor

	public Orador(int idPersona, Contacto contacto, String nombre, String apellido, String tipoDocumento, long dni,
			String areaInvestigacion) {
		super(idPersona, contacto, nombre, apellido, tipoDocumento, dni);
		this.areaInvestigacion = areaInvestigacion;
	}
	//getter y setter
	public String getAreaInvestigacion() {
		return areaInvestigacion;
	}

	public void setAreaInvestigacion(String areaInvestigacion) {
		this.areaInvestigacion = areaInvestigacion;
	}
	//toString
	@Override
	public String toString() {
		return "Orador [idPersona=" + idPersona +", "+ contacto.toString() + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", tipoDocumento=" + tipoDocumento + ", nroDocumento=" + nroDocumento + ", areaInvestigacion=" + areaInvestigacion + "]";
	}
	
}
