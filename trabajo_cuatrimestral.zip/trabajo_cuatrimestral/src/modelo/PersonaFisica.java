package modelo;

public abstract class PersonaFisica extends Persona {
	protected String nombre;
	protected String apellido;
	protected String tipoDocumento;
	protected long nroDocumento;
	//constructor
	public PersonaFisica(int idPersona, Contacto contacto, String nombre, String apellido, String tipoDocumento,
			long nroDocumento) {
		super(idPersona, contacto);
		this.nombre = nombre;
		this.apellido = apellido;
		this.tipoDocumento = tipoDocumento;
		this.nroDocumento = nroDocumento;
	}
	//getter y setter
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	public long getNroDocumento() {
		return nroDocumento;
	}
	public void setNroDocumento(long nroDocumento) {
		this.nroDocumento = nroDocumento;
	}
	//toString
	@Override
	public String toString() {
		return "PersonaFisica [nombre=" + nombre + ", apellido=" + apellido + ", tipoDocumento=" + tipoDocumento
				+ ", nroDocumento=" + nroDocumento + "]";
	}
}
