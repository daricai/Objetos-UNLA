package test;
import modelo.Contacto;
import modelo.Auspiciante;
import modelo.Orador;
import modelo.Organizador;
import modelo.Ranking;
import modelo.Espectador;
import modelo.Exposicion;
import modelo.Conferencia;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collections;
import java.util.List;

import modelo.Congreso;

public class testTrabajoCuatrimestra {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Congreso congreso = new Congreso ("Congreso Filosofia en UNLA",LocalDate.of(2019, 11, 1),LocalDate.of(2019, 12, 15), 1000);
		//1)
		System.out.println("punto 1:");
		System.out.println("Dar de alta Auspiciante");
		System.out.println(" ");
		try {
			congreso.agregarAuspiciante(new Contacto ("unqui@edu.ar", "1511111111"), "Universidad Nacional de Quilmes", "30-11111111-9",2000);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {	
			congreso.agregarAuspiciante(new Contacto ("undav@edu.ar", "1522222222"), "Universidad Nacional de Avellaneda", "30-22222222-9",3000);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarAuspiciante(new Contacto ("unlz@edu.ar", "1533333333"), "Universidad Nacional de Lomas", "30-33333333-9", 1000);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarAuspiciante(new Contacto ("utnavellaneda@edu.ar", "1544444444"), "Universidad Tecnolog�ca de Avellaneda",
					"30-44444444-9", 4000);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarAuspiciante(new Contacto ("unqui@edu.ar", "1555555555"), "Universidad Nacional de Quilmes", "30-55555555-9",2000);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarAuspiciante(new Contacto ("unlp@edu.ar", "1566666666"), "Universidad Nacional de La Plata", "30-66666666-9",2500);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarAuspiciante(new Contacto ("unla@edu.ar", "1577777777"), "Universidad Nacional de Lanus", "30-77777777-9",1500);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarAuspiciante(new Contacto ("kenedy@edu.ar", "1588888888"), "Universidad kenedy", "30-88888888-9",2100);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarAuspiciante(new Contacto ("unqui@edu.ar", "1599999999"), "Universidad Nacional de Quilmes", "30-99999999-9",3000);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarAuspiciante(new Contacto ("unqui@edu.ar", "1511111111"), "Universidad Nacional de Quilmes", "30-11111111-9",2000);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Auspiciante) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Dar de baja Auspiciante");
		System.out.println(" ");
		try {
			congreso.EliminarAuspiciante("30-22222222-9");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.EliminarAuspiciante("30-12555555-9");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Auspiciante) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Modificar Auspiciante");
		System.out.println(" ");
		try {
			congreso.modificarAuspiciante("30-12555555-9", 3000);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.modificarAuspiciante("30-33333333-9", 3000);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Auspiciante) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//2)
		System.out.println("punto 2:");
		System.out.println("Dar de alta Orador");
		System.out.println(" ");
		try {
			congreso.agregarOrador(new Contacto ("orador1@hotmail.com", "1511111111"), "orador", "uno", "dni", 11111111, "Informatica");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarOrador(new Contacto ("orador2@hotmail.com", "1511111111"), "orador", "dos", "dni", 22222222, "ciencias");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarOrador(new Contacto ("orador3@hotmail.com", "1511111111"), "orador", "tres", "dni", 33333333, "filosofos griegos");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarOrador(new Contacto ("orador4@hotmail.com", "1511111111"), "orador", "cuatro", "dni", 44444444, "filosofos romanos");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarOrador(new Contacto ("orador5@hotmail.com", "1511111111"), "orador", "cinco", "dni", 22222222, "historiador");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Orador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Dar de baja Orador");
		System.out.println(" ");
		try {
			congreso.EliminarOrador(33333333);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.EliminarOrador(12345678);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Orador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Modificar Orador");
		System.out.println(" ");
		try {
			congreso.modificarOrador(11111111, "historiador");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.modificarOrador(66666666, "antiguedad");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Orador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//3)
		System.out.println("punto 3:");
		System.out.println("Dar de alta Organizador");
		System.out.println(" ");
		try {
			congreso.agregarOrganizador(new Contacto ("organizador1@hotmail.com", "1511111111"), "organizador", "uno", "dni", 22221111);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarOrganizador(new Contacto ("organizador2@hotmail.com", "1511111111"), "organizador", "dos", "dni", 11112222);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarOrganizador(new Contacto ("organizador3@hotmail.com", "1511111111"), "organizador", "tres", "dni", 33334444);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarOrganizador(new Contacto ("organizador4@hotmail.com", "1511111111"), "organizador", "cuatro", "dni", 44443333);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Organizador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Dar de baja Organizador");
		System.out.println(" ");
		try {
			congreso.EliminarOrganizador(22221111);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.EliminarOrganizador(11111211);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Organizador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Modificar Organizador");
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		
		//4)
		System.out.println("punto 4:");
		System.out.println("Dar de alta Espectador");
		System.out.println(" ");
		try {
			congreso.agregarEspectador(new Contacto ("espectador1@hotmail.com", "1511111111"), "espectador", "uno", "dni", 11221122, "universitario");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarEspectador(new Contacto ("espectador2@hotmail.com", "1511111111"), "espectador", "dos", "dni", 22112211, "licenciado");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarEspectador(new Contacto ("espectador3@hotmail.com", "1511111111"), "espectador", "tres", "dni", 33443344, "secundario");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarEspectador(new Contacto ("espectador4@hotmail.com", "1511111111"), "espectador", "cuatro", "dni", 44334433, "terciario");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}		
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Espectador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Dar de baja espectador");
		System.out.println(" ");
		try {
			congreso.EliminarEspectador(33443344);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.EliminarEspectador(11211111);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Espectador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Modificar espectador");
		System.out.println(" ");
		try {
			congreso.modificarEspectador(11221122, "licenciado");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.modificarEspectador(11112111, "antiguedad");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Espectador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//5)
		System.out.println("punto 6:");
		System.out.println("Dar de alta Sala");
		System.out.println(" ");
		congreso.agregarSala("Jose Hernandez", 200);
		congreso.agregarSala("R. Scalabrini Ortiz", 150);
		congreso.agregarSala("Juana Manso", 50);
		congreso.agregarSala("Padre C. Mujica", 75);
		congreso.agregarSala("Ortega Pe�a", 110);
		congreso.agregarSala("Pascual Contursi", 160);
		congreso.agregarSala("Lola Mora", 180);
		congreso.agregarSala("Manuel Ugarte", 85);
		congreso.agregarSala("Enrique S. Discepole", 35);
		congreso.agregarSala("Arturo Jauretche", 170);
		congreso.agregarSala("Jose Arturo", 200);
		congreso.agregarSala("para eliminar", 200);
		for (int p=0; p<congreso.getLstSalas().size();p++) {
			System.out.println(congreso.getLstSalas().get(p));
		}
		System.out.println(" ");
		System.out.println("Dar de baja Sala");
		System.out.println(" ");
		try {
			congreso.EliminarSala(12);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.EliminarSala(20);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstSalas().size();p++) {
			System.out.println(congreso.getLstSalas().get(p));
		}
		System.out.println(" ");
		System.out.println("Modificar Sala");
		System.out.println(" ");
		try {
			congreso.modificarSala(2, "R. Scala", 30);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.modificarSala(15, "R. Scala", 30);
			}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstSalas().size();p++) {
			System.out.println(congreso.getLstSalas().get(p));
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//5)
		System.out.println("punto 5:");
		System.out.println("Dar de alta Conferencia");
		System.out.println(" ");
		try {
			congreso.agregarConferencia("Acto apertura", LocalDate.of(2019, 11, 1), congreso.traerSala(1));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarConferencia("conferencia uno", LocalDate.of(2019, 11, 6), congreso.traerSala(2));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarConferencia("conferencia dos", LocalDate.of(2019, 11, 25), congreso.traerSala(3));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarConferencia("conferencia tres", LocalDate.of(2019, 11, 6), congreso.traerSala(4));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarConferencia("conferencia cuatro", LocalDate.of(2019, 11, 25), congreso.traerSala(5));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarConferencia("conferencia cinco", LocalDate.of(2019, 12, 1), congreso.traerSala(6));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarConferencia("conferencia seis", LocalDate.of(2019, 12, 1), congreso.traerSala(7));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarConferencia("conferencia siete", LocalDate.of(2019, 10, 6), congreso.traerSala(8));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarConferencia("conferencia siete", LocalDate.of(2019, 12, 1), congreso.traerSala(9));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarConferencia("conferencia cuatro", LocalDate.of(2019, 12, 1), congreso.traerSala(10));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarConferencia("Acto clausura", LocalDate.of(2019, 12, 15), congreso.traerSala(11));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstConferencias().size();p++) {
			System.out.println(congreso.getLstConferencias().get(p));
		}
		System.out.println(" ");
		System.out.println("Dar de baja Conferencia");
		System.out.println(" ");
		try {
			congreso.EliminarConferencia("conferencia dos");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.EliminarConferencia("conferencia diez");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstConferencias().size();p++) {
			System.out.println(congreso.getLstConferencias().get(p));
		}
		System.out.println(" ");
		System.out.println("Modificar Conferencia");
		System.out.println(" ");
		try {
			congreso.modificarConferencia("conferencia tres", "conferencia 3", LocalDate.of(2019, 11, 25), congreso.traerSala(4));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.modificarConferencia("conferencia cuatro", "conferencia 4", LocalDate.of(2019, 12, 25), congreso.traerSala(5));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.modificarConferencia("conferencia diez", "conferencia 10", LocalDate.of(2019, 11, 25), congreso.traerSala(4));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstConferencias().size();p++) {
			System.out.println(congreso.getLstConferencias().get(p));
		}
		
		System.out.println(" ");
		System.out.println(" ");
		System.out.println("Dar de alta Entradas");
		System.out.println(" ");
		try{
	    	congreso.agregarEntrada("0957924", 00.00, (Espectador)congreso.traerEspectador(11221122), congreso.traerConferencia("Acto apertura"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
		try{
	    	congreso.agregarEntrada("3477924", 00.00, (Espectador)congreso.traerEspectador(22112211), congreso.traerConferencia("Acto apertura"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
		try{
	    	congreso.agregarEntrada("2397924", 00.00, (Espectador)congreso.traerEspectador(44334433), congreso.traerConferencia("Acto apertura"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
		try{
	    	congreso.agregarEntrada("2577924", 00.00, (Espectador)congreso.traerEspectador(11221122), congreso.traerConferencia("Acto clausura"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
		try{
	    	congreso.agregarEntrada("4557924", 00.00, (Espectador)congreso.traerEspectador(22112211), congreso.traerConferencia("Acto clausura"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
		try{
	    	congreso.agregarEntrada("2767923", 00.00, (Espectador)congreso.traerEspectador(44334433), congreso.traerConferencia("Acto clausura"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
		try{
	    	congreso.agregarEntrada("1234564", 350.00, (Espectador)congreso.traerEspectador(11221122), congreso.traerConferencia("conferencia uno"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
	    try{
	    	congreso.agregarEntrada("3847591", 550.00, (Espectador)congreso.traerEspectador(11221122), congreso.traerConferencia("conferencia cuatro"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
	    try{
	    	congreso.agregarEntrada("6635279", 350.00, (Espectador)congreso.traerEspectador(22112211), congreso.traerConferencia("conferencia uno"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
	    try{
	    	congreso.agregarEntrada("3948254", 700.00, (Espectador)congreso.traerEspectador(44334433), congreso.traerConferencia("conferencia cinco"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
	    try{
	    	congreso.agregarEntrada("7579623", 480.00, (Espectador)congreso.traerEspectador(44334433), congreso.traerConferencia("conferencia siete"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
	    
	    try{
	    	congreso.agregarEntrada("0557928", 500.00, (Espectador)congreso.traerEspectador(22112211), congreso.traerConferencia("conferencia seis"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
	    try{
	    	congreso.agregarEntrada("5457924", 340.00, (Espectador)congreso.traerEspectador(44334433), congreso.traerConferencia("conferencia 3"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
	    try{
	    	congreso.agregarEntrada("4657923", 340.00, (Espectador)congreso.traerEspectador(11221122), congreso.traerConferencia("conferencia 3"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
	    try{
	    	congreso.agregarEntrada("1111111", 00.00, (Espectador)congreso.traerEspectador(22112211), congreso.traerConferencia("Acto apertura"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
	    try{
	    	congreso.agregarEntrada("2577924", 00.00, (Espectador)congreso.traerEspectador(44334433), congreso.traerConferencia("Acto apertura"));
	    }catch (Exception e) {
	    	System.out.println(e.getMessage());
	    }
	    for (int p=0; p<congreso.getLstEntradas().size();p++) {
			System.out.println(congreso.getLstEntradas().get(p));
		}
	    /*System.out.println(" ");
	    System.out.println("Actualizamos las entradas con las bonificaciones correspondientes");
	    System.out.println(" ");
	    System.out.println(" ");
	    congreso.actualizarEntradas();
	    System.out.println(" ");
	    System.out.println(" ");
	    for (int p=0; p<congreso.getLstEntradas().size();p++) {
			System.out.println(congreso.getLstEntradas().get(p));
		}*/
	    //CARGAMOS  LISTA CONFERENCIA EN ORGANIZADORES
		//CARGAMOS  LISTA CONFERENCIA EN ORGANIZADORES
		//CARGAMOS  LISTA CONFERENCIA EN ORGANIZADORES
		//CARGAMOS  LISTA CONFERENCIA EN ORGANIZADORES
		System.out.println(" ");
		System.out.println("CARGAMOS  LISTA CONFERENCIA EN ORGANIZADORES ");
		System.out.println(" ");
		System.out.println(" ");
		congreso.traerOrganizador(11112222).agregarConferencia(congreso.traerConferencia("Acto apertura"));
		congreso.traerOrganizador(33334444).agregarConferencia(congreso.traerConferencia("conferencia uno"));
		congreso.traerOrganizador(33334444).agregarConferencia(congreso.traerConferencia("conferencia 3"));
		congreso.traerOrganizador(44443333).agregarConferencia(congreso.traerConferencia("conferencia cuatro"));
		congreso.traerOrganizador(11112222).agregarConferencia(congreso.traerConferencia("conferencia cinco"));
		congreso.traerOrganizador(11112222).agregarConferencia(congreso.traerConferencia("conferencia seis"));
		congreso.traerOrganizador(44443333).agregarConferencia(congreso.traerConferencia("conferencia siete"));
		congreso.traerOrganizador(11112222).agregarConferencia(congreso.traerConferencia("Acto clausura"));
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Organizador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		//CARGAMOS  LISTA DE EXPOSICIONES EN CONFERENCIA
		//CARGAMOS  LISTA DE EXPOSICIONES EN CONFERENCIA
		//CARGAMOS  LISTA DE EXPOSICIONES EN CONFERENCIA
		//CARGAMOS  LISTA DE EXPOSICIONES EN CONFERENCIA
		System.out.println(" ");
		System.out.println("CARGAMOS LISTA DE EXPOSICIONES EN CONFERENCIA ");
		System.out.println(" ");
		System.out.println(" ");
		try {
		congreso.traerConferencia("Acto apertura").agregarExposicionPresencial(congreso.traerOrador(11111111), 400, LocalTime.of(10,00 ), LocalTime.of(11, 00));   
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
		congreso.traerConferencia("conferencia uno").agregarExposicionPresencial(congreso.traerOrador(22222222), 500, LocalTime.of(10,00 ), LocalTime.of(11, 00));     
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
		congreso.traerConferencia("conferencia 3").agregarExposicionPresencial(congreso.traerOrador(11111111),224, LocalTime.of(16,00 ), LocalTime.of(17, 00));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
		congreso.traerConferencia("conferencia 3").agregarExposicionVirtual(congreso.traerOrador(11111111),500, LocalTime.of(15,00 ), LocalTime.of(16, 30),"Online via web","http://www.untvirtual.com/akrrmrm.3444");  
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
		congreso.traerConferencia("conferencia cuatro").agregarExposicionPresencial(congreso.traerOrador(22222222),200, LocalTime.of(9,00 ), LocalTime.of(11, 00));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
		congreso.traerConferencia("conferencia cinco").agregarExposicionPresencial(congreso.traerOrador(11111111),305, LocalTime.of(10,00 ), LocalTime.of(11, 00));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
		congreso.traerConferencia("conferencia seis").agregarExposicionPresencial(congreso.traerOrador(22222222),760, LocalTime.of(16,00 ), LocalTime.of(17, 00));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
		congreso.traerConferencia("conferencia seis").agregarExposicionVirtual(congreso.traerOrador(22222222),900, LocalTime.of(17,30 ), LocalTime.of(19, 00),"Online via web","http://www.untvirtual.com/aeorlk.3444");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
		congreso.traerConferencia("conferencia siete").agregarExposicionVirtual(congreso.traerOrador(44444444), 1000, LocalTime.of(10,00 ), LocalTime.of(11, 00),"Online via web","http://www.untvirtual.com/aksk.3444");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
		congreso.traerConferencia("Acto apertura").agregarExposicionPresencial(congreso.traerOrador(44444444),390, LocalTime.of(15,00 ), LocalTime.of(16, 00));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
		congreso.traerConferencia("Acto clausura").agregarExposicionPresencial(congreso.traerOrador(44444444),480, LocalTime.of(12,00 ), LocalTime.of(13, 00));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstConferencias().size();p++) {
			System.out.println(congreso.getLstConferencias().get(p));
		}
		//CARGAMOS  LISTA DE AUSPICIANTES EN CONFERENCIA
		//CARGAMOS  LISTA DE AUSPICIANTES EN CONFERENCIA
		//CARGAMOS  LISTA DE AUSPICIANTES EN CONFERENCIA
		//CARGAMOS  LISTA DE AUSPICIANTES EN CONFERENCIA
		System.out.println(" ");
		System.out.println("CARGAMOS LISTA DE AUSPICIANTES EN CONFERENCIA ");
		System.out.println(" ");
		System.out.println(" ");
		congreso.traerConferencia("Acto apertura").agregarAuspiciante(congreso.traerAuspiciante("30-11111111-9"));
		congreso.traerConferencia("Acto apertura").agregarAuspiciante(congreso.traerAuspiciante("30-33333333-9"));
		congreso.traerConferencia("conferencia uno").agregarAuspiciante(congreso.traerAuspiciante("30-44444444-9"));
		congreso.traerConferencia("conferencia uno").agregarAuspiciante(congreso.traerAuspiciante("30-55555555-9"));
		congreso.traerConferencia("conferencia 3").agregarAuspiciante(congreso.traerAuspiciante("30-66666666-9"));
		congreso.traerConferencia("conferencia 3").agregarAuspiciante(congreso.traerAuspiciante("30-77777777-9"));
		congreso.traerConferencia("conferencia cuatro").agregarAuspiciante(congreso.traerAuspiciante("30-88888888-9"));
		congreso.traerConferencia("conferencia cuatro").agregarAuspiciante(congreso.traerAuspiciante("30-99999999-9"));
		congreso.traerConferencia("conferencia cinco").agregarAuspiciante(congreso.traerAuspiciante("30-11111111-9"));
		congreso.traerConferencia("conferencia cinco").agregarAuspiciante(congreso.traerAuspiciante("30-44444444-9"));
		congreso.traerConferencia("conferencia seis").agregarAuspiciante(congreso.traerAuspiciante("30-33333333-9"));
		congreso.traerConferencia("conferencia seis").agregarAuspiciante(congreso.traerAuspiciante("30-55555555-9"));
		congreso.traerConferencia("conferencia siete").agregarAuspiciante(congreso.traerAuspiciante("30-66666666-9"));
		congreso.traerConferencia("conferencia siete").agregarAuspiciante(congreso.traerAuspiciante("30-88888888-9"));
		congreso.traerConferencia("Acto clausura").agregarAuspiciante(congreso.traerAuspiciante("30-77777777-9"));
		congreso.traerConferencia("Acto clausura").agregarAuspiciante(congreso.traerAuspiciante("30-99999999-9"));
		for (int p=0; p<congreso.getLstConferencias().size();p++) {
			System.out.println(congreso.getLstConferencias().get(p));
		}
		//CARGAMOS  LISTA DE ESPECTADORES EN EXPOSICION PRESENCIAL
		//CARGAMOS  LISTA DE ESPECTADORES EN EXPOSICION PRESENCIAL
		//CARGAMOS  LISTA DE ESPECTADORES EN EXPOSICION PRESENCIAL
		//CARGAMOS  LISTA DE ESPECTADORES EN EXPOSICION PRESENCIAL
		System.out.println(" ");
		System.out.println("CARGAMOS LISTA DE ESPECTADORES EN EXPOSICION PRESENCIAL");
		System.out.println(" ");
		System.out.println(" ");
		int i=1;
		congreso.traerConferencia("Acto apertura").traerExposicionPresencial(i).agregarEspectador(congreso.traerEspectador(22112211));
		congreso.traerConferencia("Acto apertura").traerExposicionPresencial(i).agregarEspectador(congreso.traerEspectador(44334433));
		congreso.traerConferencia("conferencia uno").traerExposicionPresencial(i).agregarEspectador(congreso.traerEspectador(11221122));
		congreso.traerConferencia("conferencia uno").traerExposicionPresencial(i).agregarEspectador(congreso.traerEspectador(22112211));
		congreso.traerConferencia("conferencia 3").traerExposicionPresencial(i).agregarEspectador(congreso.traerEspectador(44334433));
		congreso.traerConferencia("conferencia cuatro").traerExposicionPresencial(i).agregarEspectador(congreso.traerEspectador(11221122));
		congreso.traerConferencia("conferencia cinco").traerExposicionPresencial(i).agregarEspectador(congreso.traerEspectador(44334433));
		congreso.traerConferencia("conferencia seis").traerExposicionPresencial(i).agregarEspectador(congreso.traerEspectador(11221122));
		congreso.traerConferencia("Acto clausura").traerExposicionPresencial(i).agregarEspectador(congreso.traerEspectador(22112211));
		i++;
		congreso.traerConferencia("Acto apertura").traerExposicionPresencial(i).agregarEspectador(congreso.traerEspectador(22112211));
		congreso.traerConferencia("Acto apertura").traerExposicionPresencial(i).agregarEspectador(congreso.traerEspectador(44334433));
		for (int p=0; p<congreso.getLstConferencias().size();p++) {
			System.out.println(congreso.getLstConferencias().get(p));
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//7)
		System.out.println("punto 7:");
		System.out.println("Calcular precio final que debe abonar un espectador");
		System.out.println(" ");
		try {
		System.out.println("el precio que tiene que abonar el " + congreso.traerEspectador(44334433) + " es: " + congreso.calcularPrecioPorEspectador(congreso.traerEspectador(44334433)));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			System.out.println("el precio que tiene que abonar el " + congreso.traerEspectador(11221122) + " es: " + congreso.calcularPrecioPorEspectador(congreso.traerEspectador(11221122)));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			System.out.println("el precio que tiene que abonar el " + congreso.traerEspectador(22112211) + " es: " + congreso.calcularPrecioPorEspectador(congreso.traerEspectador(22112211)));
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//8)
		System.out.println("punto 8:");
		System.out.println("Reporte de conferencias por dia");
		System.out.println(" ");
		System.out.println(LocalDate.of(2019, 12, 1));
		for(Conferencia s : congreso.traerConferencia(LocalDate.of(2019, 12, 1))) {
			System.out.println(s);
		}
		System.out.println(" ");
		System.out.println(LocalDate.of(2019, 11, 25));
		for(Conferencia s : congreso.traerConferencia(LocalDate.of(2019, 11, 25))) {
			System.out.println(s);
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//9)
		System.out.println("punto 9:");
		System.out.println("Reporte de exposiciones por organizador");
		System.out.println(" ");
		System.out.println("ORGANIZADOR: " + congreso.traerOrganizador(11112222).getNombre() + " " +congreso.traerOrganizador(11112222).getApellido()+ ": " );
		System.out.println(" ");
		try {
		for(Exposicion e: congreso.exposicionPorOrganizador(congreso.traerOrganizador(11112222))) {
			System.out.println(e);
		}
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//10)
		System.out.println("punto 10:");
		System.out.println("Reporte de saldo por conferencia");
		System.out.println(" ");
		for(i=0; i<congreso.getLstConferencias().size(); i++){
			System.out.println("Conferencia: " + congreso.getLstConferencias().get(i).getTitulo());
			try {
			System.out.println("saldo total de la conferencia: "+ congreso.saldoConferencia(congreso.getLstConferencias().get(i)));
			}catch (Exception e) {
				System.out.println("Excepcion: "+ e.getMessage());
			}
			System.out.println(" ");
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//11)
		System.out.println("punto 11:");
		System.out.println("Reporte de espectadores para una exposicion");
		System.out.println(" ");
		System.out.println("Conferencia: " + congreso.traerConferencia("Acto apertura").getTitulo());
		System.out.println("Exposicion numero: "+congreso.traerConferencia("Acto apertura").traerExposicionPresencial(1).getIdExposicion());
		for (i=0; i<congreso.traerConferencia("Acto apertura").traerExposicionPresencial(1).getLstEspectador().size();i++) {
			System.out.println(congreso.traerConferencia("Acto apertura").traerExposicionPresencial(1).getLstEspectador().get(i));
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//12)
		System.out.println("punto 12:");
		System.out.println("Ranking de espectadores segun nivel de estudios");
		System.out.println(" ");
		for (i=0; i<congreso.traerRankingNivelEstudio().size();i++) {
			System.out.println(congreso.traerRankingNivelEstudio().get(i));
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//13)
		System.out.println("punto 13:");
		System.out.println("Ranking de las cinco exposiciones con mayor cantidad de butacas vacias");
		System.out.println(" ");
		List <Ranking> lstRankingButacas = congreso.traerRankingButacasVacias();
		Collections.sort(lstRankingButacas);
		for (i=0; i<lstRankingButacas.size();i++) {
			if(i<5) {
				System.out.println(lstRankingButacas.get(i) + " butacas vacias.");
			}
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//14)
		System.out.println("punto 14:");
		System.out.println("Informar saldo final del congreso");
		System.out.println(" ");
		System.out.println("Congreso: " + congreso.getNombre());
		System.out.println(" ");
		System.out.println("saldo total del congreso es: "+ congreso.calcularSaldoFinal());
	}
}
