package test;
import modelo.Contacto;
import modelo.Auspiciante;
import modelo.Orador;
import modelo.Organizador;
import modelo.Espectador;
import modelo.Conferencia;
import modelo.Sala;

import java.time.LocalDate;

import modelo.Congreso;

public class testTrabajoCuatrimestra {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Congreso congreso = new Congreso ("Congreso Filosofia en UNLA",LocalDate.of(2019, 11, 1),LocalDate.of(2019, 12, 15), 1000);
		//1)
		System.out.println("punto 1:");
		System.out.println("Dar de alta Auspiciante");
		System.out.println(" ");
		try {
			congreso.agregarAuspiciante(new Contacto ("unqui@edu.ar", "1511111111"), "Universidad Nacional de Quilmes", "30-11111111-9",2000);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {	
			congreso.agregarAuspiciante(new Contacto ("undav@edu.ar", "1522222222"), "Universidad Nacional de Avellaneda", "30-22222222-9",3000);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarAuspiciante(new Contacto ("unlz@edu.ar", "1533333333"), "Universidad Nacional de Lomas", "30-33333333-9", 1000);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarAuspiciante(new Contacto ("utnavellaneda@edu.ar", "1544444444"), "Universidad Tecnolog�ca de Avellaneda",
					"30-44444444-9", 4000);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarAuspiciante(new Contacto ("unqui@edu.ar", "1511111111"), "Universidad Nacional de Quilmes", "30-11111111-9",2000);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Auspiciante) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Dar de baja Auspiciante");
		System.out.println(" ");
		try {
			congreso.EliminarAuspiciante("30-22222222-9");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.EliminarAuspiciante("30-55555555-9");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Auspiciante) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Modificar Auspiciante");
		System.out.println(" ");
		try {
			congreso.modificarAuspiciante("30-55555555-9", 3000);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.modificarAuspiciante("30-33333333-9", 3000);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Auspiciante) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//2)
		System.out.println("punto 2:");
		System.out.println("Dar de alta Orador");
		System.out.println(" ");
		try {
			congreso.agregarOrador(new Contacto ("orador1@hotmail.com", "1511111111"), "orador", "uno", "dni", 11111111, "Informatica");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarOrador(new Contacto ("orador2@hotmail.com", "1511111111"), "orador", "dos", "dni", 22222222, "ciencias");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarOrador(new Contacto ("orador3@hotmail.com", "1511111111"), "orador", "tres", "dni", 33333333, "filosofos griegos");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarOrador(new Contacto ("orador4@hotmail.com", "1511111111"), "orador", "cuatro", "dni", 44444444, "filosofos romanos");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarOrador(new Contacto ("orador5@hotmail.com", "1511111111"), "orador", "cinco", "dni", 22222222, "historiador");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Orador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Dar de baja Orador");
		System.out.println(" ");
		try {
			congreso.EliminarOrador(33333333);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.EliminarOrador(12345678);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Orador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Modificar Orador");
		System.out.println(" ");
		try {
			congreso.modificarOrador(11111111, "historiador");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.modificarOrador(66666666, "antiguedad");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Orador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		//3)
		System.out.println("punto 3:");
		System.out.println("Dar de alta Organizador");
		System.out.println(" ");
		try {
			congreso.agregarOrganizador(new Contacto ("organizador1@hotmail.com", "1511111111"), "organizador", "uno", "dni", 22221111);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarOrganizador(new Contacto ("organizador2@hotmail.com", "1511111111"), "organizador", "dos", "dni", 11112222);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarOrganizador(new Contacto ("organizador3@hotmail.com", "1511111111"), "organizador", "tres", "dni", 33334444);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarOrganizador(new Contacto ("organizador4@hotmail.com", "1511111111"), "organizador", "cuatro", "dni", 44443333);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarOrganizador(new Contacto ("organizador5@hotmail.com", "1511111111"), "organizador", "cinco", "dni", 11111111);	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Organizador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Dar de baja Organizador");
		System.out.println(" ");
		try {
			congreso.EliminarOrganizador(22221111);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.EliminarOrganizador(11111111);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Organizador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Modificar Organizador");
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
		
		//4)
		System.out.println("punto 4:");
		System.out.println("Dar de alta Espectador");
		System.out.println(" ");
		try {
			congreso.agregarEspectador(new Contacto ("espectador1@hotmail.com", "1511111111"), "espectador", "uno", "dni", 11221122, "universitario");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.agregarEspectador(new Contacto ("espectador2@hotmail.com", "1511111111"), "espectador", "dos", "dni", 22112211, "licenciado");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarEspectador(new Contacto ("espectador3@hotmail.com", "1511111111"), "espectador", "tres", "dni", 33443344, "secundario");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarEspectador(new Contacto ("espectador4@hotmail.com", "1511111111"), "espectador", "cuatro", "dni", 44334433, "terciario");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		try {
			congreso.agregarEspectador(new Contacto ("espectador5@hotmail.com", "1511111111"), "espectador", "cinco", "dni", 11111111, "maestria");	
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}	
		
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Espectador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Dar de baja espectador");
		System.out.println(" ");
		try {
			congreso.EliminarEspectador(33443344);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.EliminarEspectador(11111111);
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Espectador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println("Modificar espectador");
		System.out.println(" ");
		try {
			congreso.modificarEspectador(11221122, "licenciado");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		try {
			congreso.modificarEspectador(11111111, "antiguedad");
		}catch (Exception e) {
			System.out.println("Excepcion: "+ e.getMessage());
		}
		for (int p=0; p<congreso.getLstPersonas().size();p++) {
			if(congreso.getLstPersonas().get(p) instanceof Espectador) {
				System.out.println(congreso.getLstPersonas().get(p));
			}
		}
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(" ");
	}
}
